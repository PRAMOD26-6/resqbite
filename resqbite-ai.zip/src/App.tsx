import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  UserPersona,
  FoodItem,
  SmartStall,
  StudentVolunteer,
  LogisticsTask,
  ShiftSlot,
  ImpactStats,
  TransactionOrder,
  AuthUser,
} from './types';
import {
  INITIAL_STALLS,
  INITIAL_FOOD_ITEMS,
  INITIAL_STUDENTS,
  INITIAL_LOGISTICS_TASKS,
  INITIAL_SHIFTS,
  INITIAL_TRANSACTIONS,
  INITIAL_IMPACT,
} from './data/initialData';
import { Navbar } from './components/Navbar';
import { BuyerMarketplace } from './components/BuyerMarketplace';
import { DonorPortal } from './components/DonorPortal';
import { StudentPortal } from './components/StudentPortal';
import { StallOperatorPortal } from './components/StallOperatorPortal';
import { InteractiveMap } from './components/InteractiveMap';
import { ImpactDashboard } from './components/ImpactDashboard';
import { SystemArchitectureView } from './components/SystemArchitectureView';
import { EcoBiteBot } from './components/EcoBiteBot';
import { QRPickupModal } from './components/QRPickupModal';
import { AuthModal } from './components/AuthModal';

export default function App() {
  const [activePersona, setActivePersona] = useState<UserPersona | 'map' | 'analytics' | 'architecture'>('consumer');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // User Auth State
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem('resqbite_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    // Default verified student account
    return {
      id: 'user-default-1',
      name: 'Aarav Sharma',
      email: 'aarav.sharma@vjti.ac.in',
      phone: '+91 98200 12345',
      role: 'student',
      isVerified: true,
      verifiedAt: new Date().toISOString(),
      verificationDetails: {
        studentId: 'SIT-2024-8841',
        university: 'VJTI Autonomous Institute, Mumbai',
        upiId: 'aarav@okaxis',
      },
    };
  });

  // Platform State
  const [stalls, setStalls] = useState<SmartStall[]>(INITIAL_STALLS);
  const [foodItems, setFoodItems] = useState<FoodItem[]>(INITIAL_FOOD_ITEMS);
  const [students, setStudents] = useState<StudentVolunteer[]>(INITIAL_STUDENTS);
  const [tasks, setTasks] = useState<LogisticsTask[]>(INITIAL_LOGISTICS_TASKS);
  const [shifts, setShifts] = useState<ShiftSlot[]>(INITIAL_SHIFTS);
  const [transactions, setTransactions] = useState<TransactionOrder[]>(INITIAL_TRANSACTIONS);
  const [impact, setImpact] = useState<ImpactStats>(INITIAL_IMPACT);

  // Modal State for QR Pickup Token
  const [qrModal, setQrModal] = useState<{
    isOpen: boolean;
    pickupToken: string;
    foodName: string;
    stallName: string;
    amount: number;
    isFreeToken: boolean;
  }>({
    isOpen: false,
    pickupToken: '',
    foodName: '',
    stallName: '',
    amount: 0,
    isFreeToken: false,
  });

  // Fetch initial data from backend API
  const fetchData = async () => {
    try {
      const res = await fetch('/api/data');
      if (res.ok) {
        const contentType = res.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const data = await res.json();
          if (data.stalls) setStalls(data.stalls);
          if (data.foodItems) setFoodItems(data.foodItems);
          if (data.students) setStudents(data.students);
          if (data.tasks) setTasks(data.tasks);
          if (data.shifts) setShifts(data.shifts);
          if (data.transactions) setTransactions(data.transactions);
          if (data.impact) setImpact(data.impact);
        }
      }
    } catch (err) {
      console.error('Failed to fetch platform data:', err);
    }
  };

  useEffect(() => {
    fetchData();
    // Poll updates every 10 seconds for real-time live synchronization
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  // Handler: Add new surplus food batch
  const handleAddFoodItem = async (newItemData: any) => {
    try {
      const res = await fetch('/api/food-items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItemData),
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error('Add food item failed:', err);
    }
  };

  // Handler: Claim Logistics Task
  const handleClaimTask = async (taskId: string, studentId: string) => {
    try {
      const res = await fetch('/api/tasks/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId, studentId }),
      });
      if (res.ok) fetchData();
    } catch (err) {
      console.error('Claim task failed:', err);
    }
  };

  // Handler: Update Logistics Task Status
  const handleUpdateTaskStatus = async (taskId: string, status: 'picked_up' | 'delivered') => {
    try {
      const res = await fetch('/api/tasks/update-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskId, status }),
      });
      if (res.ok) fetchData();
    } catch (err) {
      console.error('Update task status failed:', err);
    }
  };

  // Handler: Smart Stall Checkout / Free Token
  const handleStallCheckout = async (
    foodItemId: string,
    stallId: string,
    qty: number,
    isFreeToken: boolean,
    buyerName?: string
  ) => {
    try {
      const res = await fetch('/api/stalls/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ foodItemId, stallId, qty, isFreeToken, buyerName }),
      });
      if (res.ok) {
        const data = await res.json();
        const food = foodItems.find((f) => f.id === foodItemId);
        const stall = stalls.find((s) => s.id === stallId);

        setQrModal({
          isOpen: true,
          pickupToken: data.transaction?.pickupTokenQR || 'RESQ-QR-8812',
          foodName: food?.foodName || 'Surplus Meal',
          stallName: stall?.name || 'Smart Food Stall',
          amount: isFreeToken ? 0 : food?.currentPrice || 1.5,
          isFreeToken,
        });

        fetchData();
      }
    } catch (err) {
      console.error('Checkout failed:', err);
    }
  };

  // Handler: Claim Shift
  const handleClaimShift = async (shiftId: string, studentId: string) => {
    try {
      const res = await fetch('/api/shifts/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shiftId, studentId }),
      });
      if (res.ok) fetchData();
    } catch (err) {
      console.error('Claim shift failed:', err);
    }
  };

  return (
    <div className="min-h-screen bg-[#050204] text-rose-50 font-sans antialiased selection:bg-rose-900 selection:text-white">
      {/* Top Header Navigation */}
      <Navbar
        activePersona={activePersona}
        setActivePersona={setActivePersona}
        toggleChat={() => setIsChatOpen(!isChatOpen)}
        mealsRescuedCount={impact.mealsRescued}
        currentUser={currentUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onSignOut={() => {
          setCurrentUser(null);
          localStorage.removeItem('resqbite_user');
        }}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 overflow-hidden">
        <AnimatePresence mode="wait">
          {activePersona === 'consumer' && (
            <motion.div
              key="consumer"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <BuyerMarketplace
                foodItems={foodItems}
                stalls={stalls}
                onCheckout={(foodId, stallId, qty, isFree) =>
                  handleStallCheckout(foodId, stallId, qty, isFree, 'Student Commuter')
                }
              />
            </motion.div>
          )}

          {activePersona === 'donor' && (
            <motion.div
              key="donor"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <DonorPortal
                foodItems={foodItems}
                stalls={stalls}
                onAddFoodItem={handleAddFoodItem}
                impactMetrics={impact}
              />
            </motion.div>
          )}

          {activePersona === 'student' && (
            <motion.div
              key="student"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <StudentPortal
                students={students}
                tasks={tasks}
                shifts={shifts}
                onClaimTask={handleClaimTask}
                onUpdateTaskStatus={handleUpdateTaskStatus}
                onClaimShift={handleClaimShift}
              />
            </motion.div>
          )}

          {activePersona === 'operator' && (
            <motion.div
              key="operator"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <StallOperatorPortal
                stalls={stalls}
                foodItems={foodItems}
                onStallCheckout={(stallId, foodId, qty, isFree, name) =>
                  handleStallCheckout(foodId, stallId, qty, isFree, name)
                }
              />
            </motion.div>
          )}

          {activePersona === 'map' && (
            <motion.div
              key="map"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <InteractiveMap
                foodItems={foodItems}
                stalls={stalls}
                students={students}
                tasks={tasks}
              />
            </motion.div>
          )}

          {activePersona === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <ImpactDashboard impact={impact} />
            </motion.div>
          )}

          {activePersona === 'architecture' && (
            <motion.div
              key="architecture"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
            >
              <SystemArchitectureView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Express QR Token Modal */}
      <QRPickupModal
        isOpen={qrModal.isOpen}
        onClose={() => setQrModal((prev) => ({ ...prev, isOpen: false }))}
        pickupToken={qrModal.pickupToken}
        foodName={qrModal.foodName}
        stallName={qrModal.stallName}
        amount={qrModal.amount}
        isFreeToken={qrModal.isFreeToken}
      />

      {/* AI Assistant Chat Drawer */}
      <EcoBiteBot
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        persona={activePersona}
      />

      {/* Login and Verification Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        initialRole={activePersona === 'map' || activePersona === 'analytics' || activePersona === 'architecture' ? 'consumer' : activePersona}
        onSignInSuccess={(user) => {
          setCurrentUser(user);
          localStorage.setItem('resqbite_user', JSON.stringify(user));
          if (user.role) {
            setActivePersona(user.role);
          }
        }}
      />
    </div>
  );
}
