export interface AuthUser {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserPersona;
  isVerified: boolean;
  verifiedAt?: string;
  verificationDetails: {
    studentId?: string;
    university?: string;
    upiId?: string;
    fssaiLicense?: string;
    gstin?: string;
    stallCode?: string;
    idCardPhotoUrl?: string;
  };
  avatarUrl?: string;
}

export type UserPersona = 'donor' | 'consumer' | 'student' | 'operator';

export type FoodType = 'Cooked Meal' | 'Bakery' | 'Packaged' | 'Snacks' | 'Beverage';
export type DietaryType = 'Veg' | 'Non-Veg' | 'Vegan' | 'Halal';

export interface FoodItem {
  id: string;
  donorId: string;
  donorName: string;
  donorLocation: { name: string; lat: number; lng: number };
  foodName: string;
  type: FoodType;
  dietary: DietaryType;
  portions: number;
  remainingPortions: number;
  prepTime: string; // ISO string or format
  prepTimestamp: number;
  shelfLifeHours: number;
  originalPrice: number;
  currentPrice: number;
  discountPercent: number;
  isFreeTokenEligible: boolean;
  assignedStallId?: string;
  assignedStallName?: string;
  status: 'available' | 'reserved' | 'in_transit' | 'delivered_to_stall' | 'sold_out';
  safetyScore: number;
  safetyNotes: string;
  packagingVerified: boolean;
  photoUrl?: string;
  ttiTemperature: number; // Time-Temperature Indicator log in °C
}

export interface SmartStall {
  id: string;
  name: string;
  code: string;
  type: 'Bus Terminal' | 'Railway Station' | 'University Gate' | 'Public Hub';
  locationName: string;
  lat: number;
  lng: number;
  chilledTemp: number; // Target 2-5°C
  hotBoxTemp: number; // Target >60°C
  sensorStatus: 'optimal' | 'warning' | 'critical';
  vegCount: number;
  nonVegCount: number;
  bakeryCount: number;
  beverageCount: number;
  capacity: number;
  freeTokensDispensedToday: number;
  activeOperatorName: string;
  operatorId: string;
}

export interface StudentVolunteer {
  id: string;
  name: string;
  university: string;
  studentIdCard: string;
  transitMode: 'Bicycle' | 'Scooter' | 'Public Transit' | 'On-Foot';
  activeShift: boolean;
  lat: number;
  lng: number;
  totalEarnings: number;
  mealsRescuedCount: number;
  carbonSavedKg: number;
  badges: string[];
  streakDays: number;
  rating: number;
}

export interface LogisticsTask {
  id: string;
  foodItemId: string;
  foodName: string;
  portions: number;
  donorName: string;
  donorAddress: string;
  donorLat: number;
  donorLng: number;
  stallId: string;
  stallName: string;
  stallLat: number;
  stallLng: number;
  studentId?: string;
  studentName?: string;
  status: 'available' | 'assigned' | 'picked_up' | 'delivered';
  distanceKm: number;
  baseFare: number;
  surgeMultiplier: number;
  totalPayout: number;
  estimatedMinutes: number;
  createdAt: string;
}

export interface ShiftSlot {
  id: string;
  date: string;
  timeWindow: string; // e.g. "8:30 PM - 10:30 PM"
  stallName: string;
  claimedByStudentId?: string;
  status: 'open' | 'claimed' | 'completed';
  stipendAmount: number;
}

export interface TransactionOrder {
  id: string;
  buyerName: string;
  buyerType: 'Student' | 'Commuter' | 'Free Token Beneficiary';
  items: { foodName: string; qty: number; unitPrice: number }[];
  totalAmount: number;
  stallName: string;
  pickupTokenQR: string;
  status: 'claimed' | 'pending_pickup' | 'verified';
  timestamp: string;
}

export interface ImpactStats {
  mealsRescued: number;
  co2eOffsetKg: number;
  methaneOffsetKg: number;
  consumerMoneySaved: number;
  studentIncomeDisbursed: number;
  activeDonorsCount: number;
  activeStallsCount: number;
  esgScore: number;
}
