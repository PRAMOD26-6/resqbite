import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ImpactStats } from '../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid
} from 'recharts';
import {
  Leaf,
  DollarSign,
  TrendingUp,
  Award,
  Users,
  Building2,
  Download,
  Flame,
  Zap
} from 'lucide-react';

interface ImpactDashboardProps {
  impact: ImpactStats;
}

const IMPACT_CHART_DATA = [
  { month: 'Jan', meals: 420, co2Saved: 630, studentIncome: 18400 },
  { month: 'Feb', meals: 680, co2Saved: 1020, studentIncome: 31500 },
  { month: 'Mar', meals: 950, co2Saved: 1425, studentIncome: 46800 },
  { month: 'Apr', meals: 1240, co2Saved: 1860, studentIncome: 62000 },
  { month: 'May', meals: 1580, co2Saved: 2370, studentIncome: 86500 },
  { month: 'Jun', meals: 2100, co2Saved: 3150, studentIncome: 124200 },
  { month: 'Jul', meals: 4280, co2Saved: 6420, studentIncome: 184000 },
];

export const ImpactDashboard: React.FC<ImpactDashboardProps> = ({ impact }) => {
  const [timeframe, setTimeframe] = useState<'monthly' | 'quarterly' | 'annual'>('monthly');

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 rounded-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800 mb-1">
            <Award className="w-3.5 h-3.5" />
            <span>ResQBite Social Impact & ESG Intelligence</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Sustainability & ESG Analytics</h1>
          <p className="text-xs text-rose-300/60 mt-0.5">
            Real-time ecological & financial metrics tracking food rescue, greenhouse gas mitigation, and student gig earnings.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Timeframe selector */}
          <div className="flex items-center gap-1 bg-[#050102] p-1 rounded-xl border border-[#2d0910] relative">
            {[
              { id: 'monthly', label: 'Monthly' },
              { id: 'quarterly', label: 'Quarterly' },
              { id: 'annual', label: 'Annual YTD' },
            ].map((tf) => {
              const isActive = timeframe === tf.id;
              return (
                <button
                  key={tf.id}
                  onClick={() => setTimeframe(tf.id as any)}
                  className={`relative px-3 py-1.5 text-xs font-bold rounded-lg transition-colors z-10 ${
                    isActive ? 'text-white' : 'text-rose-400/50 hover:text-rose-200'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="esgTimeframePill"
                      className="absolute inset-0 bg-rose-700 rounded-lg shadow-md z-0"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{tf.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => alert('Downloaded Full ResQBite ESG Sustainability Audit Report (PDF)')}
            className="px-4 py-2.5 bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-rose-950/50"
          >
            <Download className="w-4 h-4" />
            <span>Export ESG Report</span>
          </button>
        </div>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-rose-300/60">
            <span>Total Meals Rescued</span>
            <Leaf className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-white">{impact.mealsRescued.toLocaleString()} meals</div>
          <span className="text-[11px] text-rose-400 font-bold">+28% growth this month</span>
        </div>

        <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-rose-300/60">
            <span>CO₂e Greenhouse Saved</span>
            <Zap className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-300">{impact.co2eOffsetKg.toLocaleString()} kg</div>
          <span className="text-[11px] text-rose-400 font-bold">Prevents landfill emission</span>
        </div>

        <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-rose-300/60">
            <span>Consumer Money Saved</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400">₹{impact.consumerMoneySaved.toLocaleString()}</div>
          <span className="text-[11px] text-amber-400 font-bold">Discounted meal savings</span>
        </div>

        <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-rose-300/60">
            <span>Student Income Generated</span>
            <Users className="w-4 h-4 text-rose-300" />
          </div>
          <div className="text-2xl font-black text-rose-200">₹{impact.studentIncomeDisbursed.toLocaleString()}</div>
          <span className="text-[11px] text-rose-300 font-bold">Disbursed via gig shifts</span>
        </div>
      </div>

      {/* Recharts Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Meals Rescued Trend */}
        <div className="bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-rose-400" />
            Cumulative Meals Rescued & Carbon Offset Trend
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={IMPACT_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2d0910" />
                <XAxis dataKey="month" stroke="#9f1239" fontSize={11} />
                <YAxis stroke="#9f1239" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e0306', borderColor: '#2d0910', borderRadius: '12px', color: '#fda4af' }}
                />
                <Area type="monotone" dataKey="meals" stroke="#e11d48" fill="#e11d4830" name="Meals Saved" />
                <Area type="monotone" dataKey="co2Saved" stroke="#fda4af" fill="#fda4af20" name="CO₂ Offset (kg)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Student Income Disbursed */}
        <div className="bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            Student Gig Income Disbursed (₹)
          </h3>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={IMPACT_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2d0910" />
                <XAxis dataKey="month" stroke="#9f1239" fontSize={11} />
                <YAxis stroke="#9f1239" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0e0306', borderColor: '#2d0910', borderRadius: '12px', color: '#fda4af' }}
                />
                <Bar dataKey="studentIncome" fill="#e11d48" radius={[6, 6, 0, 0]} name="Payout (₹)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
