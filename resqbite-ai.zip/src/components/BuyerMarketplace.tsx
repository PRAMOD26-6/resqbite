import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FoodItem, SmartStall, DietaryType } from '../types';
import {
  Search,
  Clock,
  Sparkles,
  ShieldCheck,
  Building2,
  Ticket,
  ChevronRight,
  Flame,
  Award,
  Filter
} from 'lucide-react';

interface BuyerMarketplaceProps {
  foodItems: FoodItem[];
  stalls: SmartStall[];
  onCheckout: (foodItemId: string, stallId: string, qty: number, isFreeToken: boolean) => void;
}

export const BuyerMarketplace: React.FC<BuyerMarketplaceProps> = ({
  foodItems,
  stalls,
  onCheckout,
}) => {
  const [selectedDietary, setSelectedDietary] = useState<string>('All');
  const [maxPrice, setMaxPrice] = useState<number>(100);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isStudentVerified, setIsStudentVerified] = useState<boolean>(true);
  const [showFreeTokensOnly, setShowFreeTokensOnly] = useState<boolean>(false);

  // Filter food items
  const filteredItems = foodItems.filter((item) => {
    if (item.remainingPortions <= 0) return false;
    if (selectedDietary !== 'All' && item.dietary !== selectedDietary) return false;
    if (showFreeTokensOnly && !item.isFreeTokenEligible) return false;
    if (item.currentPrice > maxPrice) return false;
    if (
      searchQuery &&
      !item.foodName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.donorName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.assignedStallName?.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Hero Banner with Student Verification & Flash Clearance Clock */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 shadow-2xl text-rose-100">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-rose-800/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800">
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>AI Dynamic Flash Clearance Engine • 70% to 85% OFF</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              ResQBite Buyer Marketplace
            </h1>
            <p className="text-sm text-rose-200/80">
              Fresh surplus meals from top restaurants, bakeries & caterers — routed directly to neighborhood Smart Food Stalls.
            </p>
          </div>

          {/* Student Verification & Free Token Card */}
          <div className="bg-[#120407] border border-rose-900/60 p-4 rounded-xl flex flex-col gap-2.5 w-full md:w-auto min-w-[260px]">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-rose-200 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-rose-400" />
                Student ID Discount
              </span>
              <button
                onClick={() => setIsStudentVerified(!isStudentVerified)}
                className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  isStudentVerified ? 'bg-rose-600' : 'bg-stone-800'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    isStudentVerified ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
            <p className="text-[11px] text-rose-300/70">
              {isStudentVerified
                ? '✓ Verified Student (Extra 10% auto-applied at checkout)'
                : 'Click to verify Student ID for extra discounts.'}
            </p>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl shadow-lg space-y-4 text-rose-100">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 absolute left-3 top-3 text-rose-400/60" />
            <input
              type="text"
              placeholder="Search dishes, restaurants, stalls..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#050102] border border-[#2d0910] rounded-xl pl-9 pr-3 py-2 text-xs text-rose-100 placeholder-rose-400/40 focus:outline-none focus:border-rose-600"
            />
          </div>

          {/* Dietary Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none relative">
            {['All', 'Veg', 'Non-Veg', 'Vegan', 'Halal'].map((diet) => {
              const isSelected = selectedDietary === diet;
              return (
                <button
                  key={diet}
                  onClick={() => setSelectedDietary(diet)}
                  className={`relative px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors z-10 ${
                    isSelected
                      ? 'text-white font-bold'
                      : 'bg-[#050102] text-rose-300/70 hover:text-rose-100 border border-[#2d0910]'
                  }`}
                >
                  {isSelected && (
                    <motion.div
                      layoutId="activeDietaryPill"
                      className="absolute inset-0 bg-rose-700 rounded-lg shadow-md shadow-rose-900/40 z-0"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{diet}</span>
                </button>
              );
            })}
          </div>

          {/* Max Price Slider & Free Token Toggle */}
          <div className="flex items-center gap-4 w-full md:w-auto justify-between">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-rose-400/60" />
              <span className="text-xs text-rose-300/70">Max Price:</span>
              <span className="text-xs font-bold text-rose-400">₹{maxPrice}</span>
              <input
                type="range"
                min="10"
                max="250"
                step="5"
                value={maxPrice}
                onChange={(e) => setMaxPrice(parseFloat(e.target.value))}
                className="w-24 accent-rose-600 cursor-pointer"
              />
            </div>

            <button
              onClick={() => setShowFreeTokensOnly(!showFreeTokensOnly)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                showFreeTokensOnly
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-[#050102] text-rose-300/70 border-[#2d0910] hover:text-amber-300'
              }`}
            >
              <Ticket className="w-3.5 h-3.5 text-amber-400" />
              <span>Free Tokens</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Food Items */}
      <AnimatePresence mode="popLayout">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredItems.map((item) => {
            const hoursLeft = Math.max(0, item.shelfLifeHours - (Date.now() - item.prepTimestamp) / (3600 * 1000));
            const effectivePrice = isStudentVerified ? +(item.currentPrice * 0.9).toFixed(2) : item.currentPrice;

            return (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className="bg-[#0f0407] border border-[#2d0910] hover:border-rose-700/60 rounded-2xl overflow-hidden shadow-2xl transition-colors group flex flex-col justify-between"
              >
              <div>
                {/* Photo Header & Badges */}
                <div className="relative h-44 w-full overflow-hidden bg-black">
                  <img
                    src={item.photoUrl}
                    alt={item.foodName}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f0407] via-transparent to-black/50" />

                  {/* Discount Badge */}
                  <div className="absolute top-3 left-3 bg-gradient-to-r from-rose-700 to-rose-600 text-white font-black text-xs px-2.5 py-1 rounded-full shadow-lg">
                    {item.discountPercent}% OFF
                  </div>

                  {/* AI Quality Guard Badge */}
                  <div className="absolute top-3 right-3 bg-[#0a0204]/90 backdrop-blur-md border border-rose-800 text-rose-200 font-bold text-[11px] px-2.5 py-1 rounded-full flex items-center gap-1 shadow-lg">
                    <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
                    <span>Grade A {item.safetyScore}/100</span>
                  </div>

                  {/* Dietary pill */}
                  <div className="absolute bottom-3 left-3 bg-black/80 backdrop-blur-md text-rose-200 text-[11px] font-semibold px-2 py-0.5 rounded-md border border-rose-900/60">
                    {item.dietary} • {item.type}
                  </div>
                </div>

                {/* Content Details */}
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="font-bold text-rose-100 text-base leading-tight group-hover:text-rose-400 transition-colors">
                      {item.foodName}
                    </h3>
                    <p className="text-xs text-rose-300/60 font-medium mt-0.5">
                      by {item.donorName}
                    </p>
                  </div>

                  {/* Location & Stall Node */}
                  <div className="flex items-center gap-1.5 text-xs text-rose-200 bg-[#1c050a] border border-rose-900/60 p-2 rounded-xl">
                    <Building2 className="w-4 h-4 text-rose-400 flex-shrink-0" />
                    <span className="truncate">Stall: <strong>{item.assignedStallName}</strong></span>
                  </div>

                  {/* Timer & Stock Count */}
                  <div className="flex items-center justify-between text-xs text-rose-300/70 pt-1">
                    <div className="flex items-center gap-1 text-amber-400 font-medium">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Expires in ~{hoursLeft.toFixed(1)}h</span>
                    </div>
                    <div className="font-semibold text-rose-300 bg-rose-950/70 px-2 py-0.5 rounded border border-rose-900/80">
                      {item.remainingPortions} portions left
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer Pricing & CTA */}
              <div className="p-4 pt-0 border-t border-rose-950 mt-2 space-y-2">
                <div className="flex items-baseline justify-between">
                  <div className="flex items-baseline gap-2">
                    <span className="text-rose-400/50 line-through text-xs font-semibold">
                      ₹{item.originalPrice.toFixed(2)}
                    </span>
                    <span className="text-xl font-extrabold text-white">
                      ₹{effectivePrice.toFixed(2)}
                    </span>
                    {isStudentVerified && (
                      <span className="text-[10px] text-rose-300 font-bold bg-rose-950 px-1.5 py-0.5 rounded border border-rose-800">
                        Student Price
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() =>
                      onCheckout(item.id, item.assignedStallId || 'stall-1', 1, false)
                    }
                    className="w-full py-2 px-3 rounded-xl bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs transition-all flex items-center justify-center gap-1 shadow-md shadow-rose-950/50"
                  >
                    <span>Reserve QR</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() =>
                      onCheckout(item.id, item.assignedStallId || 'stall-1', 1, true)
                    }
                    disabled={!item.isFreeTokenEligible}
                    className={`w-full py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 border ${
                      item.isFreeTokenEligible
                        ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/50'
                        : 'bg-[#050102] text-stone-600 border-[#2d0910] cursor-not-allowed'
                    }`}
                  >
                    <Ticket className="w-3.5 h-3.5 text-amber-400" />
                    <span>{item.isFreeTokenEligible ? 'Free Token' : 'Not Eligible'}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
      </AnimatePresence>

      {filteredItems.length === 0 && (
        <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400">
          <Sparkles className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-50" />
          <p className="font-semibold text-slate-200">No surplus food items match your criteria.</p>
          <p className="text-xs text-slate-500 mt-1">Try resetting dietary filters or price limit.</p>
        </div>
      )}
    </div>
  );
};
