import React from 'react';
import { motion } from 'motion/react';
import {
  UserPersona,
  AuthUser
} from '../types';
import {
  ShoppingBag,
  Store,
  Bike,
  Building2,
  BarChart3,
  MapPin,
  Code2,
  Bot,
  Sparkles,
  Zap,
  Leaf,
  UserCheck,
  ShieldCheck,
  LogOut,
  User
} from 'lucide-react';

interface NavbarProps {
  activePersona: UserPersona | 'map' | 'analytics' | 'architecture';
  setActivePersona: (p: UserPersona | 'map' | 'analytics' | 'architecture') => void;
  toggleChat: () => void;
  mealsRescuedCount: number;
  currentUser: AuthUser | null;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePersona,
  setActivePersona,
  toggleChat,
  mealsRescuedCount,
  currentUser,
  onOpenAuthModal,
  onSignOut,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-black/90 backdrop-blur-md border-b border-[#3b0d17] text-rose-100 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActivePersona('consumer')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-900 via-rose-700 to-rose-500 p-0.5 shadow-lg shadow-rose-900/40 flex items-center justify-center">
              <div className="w-full h-full bg-[#0a0305] rounded-[10px] flex items-center justify-center">
                <Leaf className="w-5 h-5 text-rose-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xl tracking-tight bg-gradient-to-r from-rose-200 via-rose-300 to-rose-400 bg-clip-text text-transparent">
                  ResQBite
                </span>
                <span className="text-[10px] uppercase font-mono tracking-widest px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                  AI
                </span>
              </div>
              <p className="text-[10px] text-rose-300/60 font-medium hidden sm:block">
                Surplus Food & Smart Logistics Platform
              </p>
            </div>
          </div>

          {/* Persona & Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#0a0305] p-1 rounded-xl border border-[#2a0810] relative">
            {[
              { id: 'consumer', label: 'Buyer', icon: ShoppingBag },
              { id: 'donor', label: 'Restaurant', icon: Store },
              { id: 'student', label: 'Gig Volunteers', icon: Bike },
              { id: 'operator', label: 'Smart Stalls', icon: Building2 },
              { id: 'map', label: 'Live Map', icon: MapPin },
              { id: 'analytics', label: 'Impact ESG', icon: BarChart3 },
              { id: 'architecture', label: 'System Architecture', icon: Code2 },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activePersona === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActivePersona(tab.id as any)}
                  className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors z-10 ${
                    isActive ? 'text-white font-bold' : 'text-rose-200/70 hover:text-rose-300'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activePersonaPill"
                      className="absolute inset-0 rounded-lg bg-gradient-to-r from-rose-800 to-rose-700 shadow-md shadow-rose-900/40 border border-rose-600/40"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-1.5">
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </nav>

          {/* Quick Metrics & AI Bot trigger */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#18060a] border border-[#3b0d17] text-rose-300 text-xs font-medium">
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>
                Rescued: <strong className="text-white">{mealsRescuedCount}</strong> meals
              </span>
            </div>

            <button
              onClick={toggleChat}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-700 via-rose-800 to-wine-600 hover:from-rose-600 hover:to-rose-700 text-white font-bold text-xs shadow-lg shadow-rose-900/40 transition-all hover:scale-105 active:scale-95 border border-rose-500/30"
            >
              <Bot className="w-4 h-4 text-rose-200" />
              <span className="hidden sm:inline">EcoBite Bot</span>
              <Sparkles className="w-3 h-3 text-amber-300" />
            </button>

            {/* Auth Profile / Sign In Button */}
            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-[#3b0d17]">
                <button
                  onClick={onOpenAuthModal}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0a0305] border border-rose-800/60 text-xs text-rose-100 hover:border-rose-500 transition-all"
                >
                  <div className="w-6 h-6 rounded-lg bg-rose-900/60 border border-rose-700 flex items-center justify-center text-rose-200 font-bold">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="text-left hidden md:block">
                    <span className="block font-bold text-rose-100 text-[11px] leading-tight">
                      {currentUser.name}
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-rose-400 inline" />
                      Verified {currentUser.role}
                    </span>
                  </div>
                </button>
                <button
                  onClick={onSignOut}
                  title="Sign Out"
                  className="p-2 text-rose-300/60 hover:text-rose-300 rounded-xl hover:bg-rose-950 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 font-bold text-xs hover:bg-rose-900 hover:border-rose-600 transition-all shadow-md shadow-rose-950/40"
              >
                <UserCheck className="w-3.5 h-3.5 text-rose-400" />
                <span>Sign In / Verify</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="lg:hidden flex items-center justify-between overflow-x-auto py-2 gap-1 border-t border-[#2a0810] scrollbar-none">
          {[
            { id: 'consumer', label: 'Buyer' },
            { id: 'donor', label: 'Restaurant' },
            { id: 'student', label: 'Volunteers' },
            { id: 'operator', label: 'Smart Stalls' },
            { id: 'map', label: 'Live Map' },
            { id: 'analytics', label: 'ESG Impact' },
            { id: 'architecture', label: 'Architecture' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActivePersona(tab.id as any)}
              className={`px-2.5 py-1 rounded-md text-xs whitespace-nowrap font-medium ${
                activePersona === tab.id ? 'bg-rose-700 text-white font-bold shadow-md shadow-rose-900/30' : 'text-rose-300/70'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
