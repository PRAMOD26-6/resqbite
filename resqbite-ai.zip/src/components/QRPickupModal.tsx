import React from 'react';
import { QrCode, CheckCircle2, Building2, Ticket, X } from 'lucide-react';

interface QRPickupModalProps {
  isOpen: boolean;
  onClose: () => void;
  pickupToken: string;
  foodName: string;
  stallName: string;
  amount: number;
  isFreeToken?: boolean;
}

export const QRPickupModal: React.FC<QRPickupModalProps> = ({
  isOpen,
  onClose,
  pickupToken,
  foodName,
  stallName,
  amount,
  isFreeToken,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0e0306] border border-rose-900/60 rounded-2xl p-6 max-w-sm w-full text-center relative shadow-2xl shadow-rose-950/50 text-slate-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-rose-400/60 hover:text-white p-1 rounded-lg hover:bg-rose-950"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-12 h-12 rounded-full bg-rose-950 text-rose-300 border border-rose-700 flex items-center justify-center mx-auto mb-3">
          {isFreeToken ? <Ticket className="w-6 h-6 text-amber-400" /> : <CheckCircle2 className="w-6 h-6 text-rose-400" />}
        </div>

        <h3 className="text-xl font-bold text-white mb-1">
          {isFreeToken ? 'Free Subsidized Token Issued!' : 'Order Confirmed!'}
        </h3>
        <p className="text-xs text-rose-300/60 mb-4">
          Scan this digital QR token at the Smart Stall scanner to retrieve your meal.
        </p>

        {/* QR Code Container */}
        <div className="bg-white p-4 rounded-xl inline-block mb-4 shadow-inner">
          <div className="w-44 h-44 bg-[#050102] rounded-lg flex flex-col items-center justify-center p-2 relative group">
            {/* Visual SVG QR Code simulation */}
            <QrCode className="w-32 h-32 text-rose-500" />
            <span className="font-mono text-[11px] font-bold text-rose-300 mt-1 tracking-wider">
              {pickupToken}
            </span>
          </div>
        </div>

        <div className="bg-[#050102] rounded-xl p-3 text-left border border-[#2d0910] text-xs space-y-1.5 mb-5">
          <div className="flex justify-between text-rose-300/60">
            <span>Item:</span>
            <span className="font-semibold text-rose-100 text-right truncate max-w-[180px]">
              {foodName}
            </span>
          </div>
          <div className="flex justify-between text-rose-300/60">
            <span>Pickup Stall:</span>
            <span className="font-semibold text-rose-400 flex items-center gap-1">
              <Building2 className="w-3 h-3" /> {stallName}
            </span>
          </div>
          <div className="flex justify-between text-rose-300/60 pt-1 border-t border-[#2d0910]">
            <span>Total Paid:</span>
            <span className="font-bold text-white">
              {isFreeToken ? 'FREE (₹0 Subsidized)' : `₹${amount.toFixed(2)}`}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-800 via-rose-700 to-rose-600 hover:from-rose-700 hover:to-rose-500 text-white font-bold text-sm transition-all shadow-lg shadow-rose-950/50"
        >
          Done & Close
        </button>
      </div>
    </div>
  );
};
