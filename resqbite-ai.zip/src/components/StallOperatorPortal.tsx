import React, { useState } from 'react';
import { SmartStall, FoodItem } from '../types';
import {
  Building2,
  Thermometer,
  QrCode,
  CheckCircle2,
  AlertTriangle,
  Ticket,
  Flame,
  Snowflake,
  ShieldAlert,
  Search,
  Box
} from 'lucide-react';

interface StallOperatorPortalProps {
  stalls: SmartStall[];
  foodItems: FoodItem[];
  onStallCheckout: (stallId: string, foodItemId: string, qty: number, isFreeToken: boolean, buyerName?: string) => void;
}

export const StallOperatorPortal: React.FC<StallOperatorPortalProps> = ({
  stalls,
  foodItems,
  onStallCheckout,
}) => {
  const [selectedStallId, setSelectedStallId] = useState<string>(stalls[0]?.id || 'stall-1');
  const [scannedQR, setScannedQR] = useState('');
  const [scanStatus, setScanStatus] = useState<string>('');
  const [simulatedSensorAlert, setSimulatedSensorAlert] = useState(false);

  const activeStall = stalls.find((s) => s.id === selectedStallId) || stalls[0];

  const handleVerifyQR = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannedQR) return;

    // Pick first available food item at this stall
    const stallItem = foodItems.find((f) => f.assignedStallId === activeStall.id && f.remainingPortions > 0);
    if (!stallItem) {
      setScanStatus('⚠ Error: No remaining inventory associated with this token at this stall.');
      return;
    }

    const isFree = scannedQR.toUpperCase().includes('FREE');
    onStallCheckout(activeStall.id, stallItem.id, 1, isFree, 'Stall QR Buyer');

    setScanStatus(`✓ QR Verified! Dispensed 1x ${stallItem.foodName}. Token ${scannedQR} marked CLAIMED.`);
    setScannedQR('');
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Top Banner & Stall Selector */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 rounded-2xl shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800 mb-1">
              <Building2 className="w-3.5 h-3.5" />
              <span>Physical Smart Stall Operator & Supervisor Hub</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white">Smart Stall Management</h1>
            <p className="text-xs text-rose-300/60 mt-0.5">
              Operator Name: <strong className="text-rose-200">{activeStall.activeOperatorName}</strong> • ID:{' '}
              <span className="font-mono">{activeStall.operatorId}</span>
            </p>
          </div>

          {/* Stall Selector Dropdown */}
          <div className="w-full md:w-auto">
            <label className="block text-[11px] text-rose-300/70 font-semibold mb-1">Select Physical Node</label>
            <select
              value={selectedStallId}
              onChange={(e) => setSelectedStallId(e.target.value)}
              className="bg-[#050102] border border-rose-800/80 text-rose-200 font-bold text-xs rounded-xl px-4 py-2.5 focus:outline-none focus:border-rose-600 w-full"
            >
              {stalls.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Real-Time Categorized Inventory Counter */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-2">
          <div className="bg-[#050102] p-3.5 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 font-medium block">Veg Meals</span>
            <span className="text-xl font-bold text-rose-400">{activeStall.vegCount} portions</span>
          </div>

          <div className="bg-[#050102] p-3.5 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 font-medium block">Non-Veg Meals</span>
            <span className="text-xl font-bold text-amber-400">{activeStall.nonVegCount} portions</span>
          </div>

          <div className="bg-[#050102] p-3.5 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 font-medium block">Bakery Goods</span>
            <span className="text-xl font-bold text-rose-300">{activeStall.bakeryCount} items</span>
          </div>

          <div className="bg-[#050102] p-3.5 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 font-medium block">Free Tokens Today</span>
            <span className="text-xl font-bold text-amber-300">{activeStall.freeTokensDispensedToday} tokens</span>
          </div>
        </div>
      </div>

      {/* Main Grid: IoT Sensor Monitor + QR Express Checkout Scanner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: IoT Temperature Sensor Monitor */}
        <div className="lg:col-span-6 bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#2d0910] pb-3">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <Thermometer className="w-5 h-5 text-rose-400" />
              IoT Insulated Storage Temperature Monitor
            </h3>
            <button
              onClick={() => setSimulatedSensorAlert(!simulatedSensorAlert)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border ${
                simulatedSensorAlert
                  ? 'bg-red-950 text-red-300 border-red-500'
                  : 'bg-[#050102] text-rose-300/60 border-[#2d0910] hover:text-white'
              }`}
            >
              {simulatedSensorAlert ? '⚠ Reset Alert' : 'Simulate Temp Alert'}
            </button>
          </div>

          {/* Sensor alert notice */}
          {simulatedSensorAlert && (
            <div className="bg-red-950/80 border border-red-500 p-3 rounded-xl text-xs text-red-200 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 animate-bounce" />
              <span>
                CRITICAL ALERT: Chilled Storage Unit temperature spiked to 8.5°C! Automated cooling system engaged.
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Chilled Unit Gauge */}
            <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-rose-200 flex items-center gap-1">
                  <Snowflake className="w-4 h-4 text-rose-400" />
                  Chilled Storage Unit
                </span>
                <span className="text-[10px] font-mono text-rose-300">Target: 2°C - 5°C</span>
              </div>
              <div className="text-2xl font-black text-rose-300">
                {simulatedSensorAlert ? '8.5°C ⚠' : `${activeStall.chilledTemp}°C`}
              </div>
              <div className="w-full h-2 bg-[#0e0306] rounded-full overflow-hidden border border-[#2d0910]">
                <div
                  className={`h-full transition-all duration-500 ${
                    simulatedSensorAlert ? 'bg-red-500 w-4/5' : 'bg-rose-600 w-2/5'
                  }`}
                />
              </div>
              <p className="text-[11px] text-rose-300/60">Status: {simulatedSensorAlert ? 'Warning' : 'Optimal'}</p>
            </div>

            {/* Hot Box Unit Gauge */}
            <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-rose-200 flex items-center gap-1">
                  <Flame className="w-4 h-4 text-amber-400" />
                  Thermal Hot Box Unit
                </span>
                <span className="text-[10px] font-mono text-amber-400">Target: &gt; 60°C</span>
              </div>
              <div className="text-2xl font-black text-amber-400">{activeStall.hotBoxTemp}°C</div>
              <div className="w-full h-2 bg-[#0e0306] rounded-full overflow-hidden border border-[#2d0910]">
                <div className="h-full bg-amber-400 w-3/4" />
              </div>
              <p className="text-[11px] text-rose-300/60">Status: Optimal Core Heat</p>
            </div>
          </div>
        </div>

        {/* Right: Express QR Scanner Simulation */}
        <div className="lg:col-span-6 bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <QrCode className="w-5 h-5 text-rose-400" />
            Express QR Code Verification Scanner
          </h3>
          <p className="text-xs text-rose-300/60">
            Scan or enter a buyer's digital pickup token to verify and dispense meals instantly.
          </p>

          <form onSubmit={handleVerifyQR} className="space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-rose-400/50" />
              <input
                type="text"
                placeholder="Enter or scan QR token (e.g. RESQ-QR-901 or FREE-TOKEN-8812)"
                value={scannedQR}
                onChange={(e) => setScannedQR(e.target.value)}
                className="w-full bg-[#050102] border border-[#2d0910] rounded-xl pl-10 pr-4 py-3 text-xs font-mono text-rose-200 placeholder-rose-400/40 focus:outline-none focus:border-rose-600"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-rose-800 via-rose-700 to-rose-600 hover:from-rose-700 hover:to-rose-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-rose-950/50"
            >
              Verify Token & Dispense Meal
            </button>
          </form>

          {scanStatus && (
            <div
              className={`p-3 rounded-xl text-xs font-semibold ${
                scanStatus.includes('Error')
                  ? 'bg-red-950 text-red-300 border border-red-500'
                  : 'bg-rose-950 text-rose-200 border border-rose-800'
              }`}
            >
              {scanStatus}
            </div>
          )}

          {/* Subsidized Free Meal Token Dispenser Panel */}
          <div className="bg-[#050102] p-4 rounded-xl border border-amber-500/30 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300 flex items-center gap-1.5">
                <Ticket className="w-4 h-4 text-amber-400" />
                Direct Free Meal Token Dispenser
              </span>
              <span className="text-[10px] text-rose-300/60">Funded by Platform Impact Reserve</span>
            </div>
            <p className="text-rose-300/60 text-[11px]">
              For verified needy individuals arriving at stall without smartphone access.
            </p>
            <button
              onClick={() => {
                const stallItem = foodItems.find((f) => f.assignedStallId === activeStall.id && f.remainingPortions > 0);
                if (stallItem) {
                  onStallCheckout(activeStall.id, stallItem.id, 1, true, 'Walk-in Beneficiary');
                  alert('Free Meal Token dispensed to walk-in beneficiary!');
                }
              }}
              className="w-full py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg font-bold text-xs transition-all"
            >
              Dispense Subsidized Free Meal Token
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
