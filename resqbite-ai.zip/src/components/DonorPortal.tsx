import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FoodItem, SmartStall, FoodType, DietaryType } from '../types';
import {
  PlusCircle,
  ShieldCheck,
  Building2,
  FileCheck,
  Award,
  Sparkles,
  Camera,
  Loader2,
  Download
} from 'lucide-react';

interface DonorPortalProps {
  foodItems: FoodItem[];
  stalls: SmartStall[];
  onAddFoodItem: (newItemData: any) => void;
  impactMetrics: any;
}

export const DonorPortal: React.FC<DonorPortalProps> = ({
  foodItems,
  stalls,
  onAddFoodItem,
  impactMetrics,
}) => {
  const [donorName, setDonorName] = useState('Punjab Grill & Tandoor House');
  const [foodName, setFoodName] = useState('');
  const [type, setType] = useState<FoodType>('Cooked Meal');
  const [dietary, setDietary] = useState<DietaryType>('Veg');
  const [portions, setPortions] = useState(25);
  const [shelfLifeHours, setShelfLifeHours] = useState(5);
  const [originalPrice, setOriginalPrice] = useState(180);
  const [assignedStallId, setAssignedStallId] = useState(stalls[0]?.id || 'stall-1');
  const [photoUrl, setPhotoUrl] = useState('');

  const [inspecting, setInspecting] = useState(false);
  const [aiInspectionResult, setAiInspectionResult] = useState<{
    safetyScore: number;
    safetyNotes: string;
    packagingVerified: boolean;
    suggestedDiscount: number;
  } | null>(null);

  const [showTaxReceipt, setShowTaxReceipt] = useState(false);

  // Trigger server-side Gemini Food Inspection
  const handleInspectFood = async () => {
    if (!foodName) return;
    setInspecting(true);
    try {
      const res = await fetch('/api/food-items/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          foodName,
          foodType: type,
          dietary,
          photoBase64: photoUrl,
          description: `Fresh surplus ${foodName} prepared today by ${donorName}.`,
        }),
      });
      const data = await res.json();
      setAiInspectionResult(data);
    } catch (err) {
      console.error('Inspection failed:', err);
    } finally {
      setInspecting(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName) return;

    onAddFoodItem({
      donorName: donorName || 'Royal Spice Kitchen',
      foodName,
      type,
      dietary,
      portions,
      shelfLifeHours,
      originalPrice,
      photoUrl:
        photoUrl ||
        'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80',
      assignedStallId,
    });

    // Reset form
    setFoodName('');
    setAiInspectionResult(null);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 rounded-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800 mb-2">
            <Building2 className="w-3.5 h-3.5" />
            <span>Food Donor & Business Partner Portal</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Log Surplus Food Inventory</h1>
          <p className="text-xs text-rose-200/80 mt-1">
            Turn unsold quality meals into social impact, tax credits, and cost recovery in real time.
          </p>
        </div>

        <button
          onClick={() => setShowTaxReceipt(!showTaxReceipt)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0a0204] border border-rose-800/80 text-rose-200 font-bold text-xs hover:bg-[#18060a] transition-all shadow-lg"
        >
          <FileCheck className="w-4 h-4 text-rose-400" />
          <span>ESG & Tax Credit Certificate</span>
        </button>
      </div>

      {/* ESG Tax Credit Modal / Panel */}
      <AnimatePresence>
        {showTaxReceipt && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -10 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden bg-[#0e0306] border border-rose-900/60 p-6 rounded-2xl shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-[#2d0910] pb-3">
              <div className="flex items-center gap-2">
                <Award className="w-6 h-6 text-amber-400" />
                <div>
                  <h3 className="font-bold text-base text-white">Automated ESG Tax Credit Receipt</h3>
                  <p className="text-xs text-rose-300/60">ResQBite Zero-Waste Compliance Standard</p>
                </div>
              </div>
              <span className="text-xs font-mono text-rose-300 font-bold bg-rose-950 px-2.5 py-1 rounded border border-rose-800">
                ID: CERT-RESQ-2026-8812
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="bg-[#050102] p-3 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block">Total Surplus Donated</span>
                <span className="text-lg font-bold text-white">420 Portions</span>
              </div>
              <div className="bg-[#050102] p-3 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block">Carbon Offsets Generated</span>
                <span className="text-lg font-bold text-rose-400">630.0 kg CO₂e</span>
              </div>
              <div className="bg-[#050102] p-3 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block">Est. Corporate Tax Credit</span>
                <span className="text-lg font-bold text-amber-400">₹75,600.00 Deduction</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => alert('ESG Compliance Certificate downloaded as PDF!')}
                className="px-4 py-2 bg-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 hover:bg-rose-600 transition-all shadow-md shadow-rose-950/50"
              >
                <Download className="w-3.5 h-3.5" />
                Download Official Tax Certificate (PDF)
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Grid: Form + AI Guard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Listing Form */}
        <div className="lg:col-span-7 bg-[#0e0306] border border-[#2d0910] p-6 rounded-2xl shadow-xl space-y-4">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-rose-400" />
            New Surplus Batch Entry
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-rose-200 font-medium mb-1">Restaurant / Donor Partner</label>
              <select
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
              >
                <option value="Punjab Grill & Tandoor House">Punjab Grill & Tandoor House</option>
                <option value="Royal Spice Restaurant & Catering">Royal Spice Restaurant & Catering</option>
                <option value="Artisan Oven Bakery">Artisan Oven Bakery</option>
                <option value="Grand Hotel & Convention Buffet">Grand Hotel & Convention Buffet</option>
                <option value="Green Leaf Vegan Café">Green Leaf Vegan Café</option>
                <option value="South Flavors Tiffin Room">South Flavors Tiffin Room</option>
                <option value="Wok & Roll Asian Bistro">Wok & Roll Asian Bistro</option>
                <option value="Coastal Catch Seafood & Curry House">Coastal Catch Seafood & Curry House</option>
                <option value="Mithai & Chaat Junction">Mithai & Chaat Junction</option>
              </select>
            </div>

            <div>
              <label className="block text-rose-200 font-medium mb-1">Dish Name / Description</label>
              <input
                type="text"
                required
                placeholder="e.g. Paneer Butter Masala & Basmati Rice"
                value={foodName}
                onChange={(e) => setFoodName(e.target.value)}
                className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-rose-200 font-medium mb-1">Category</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as FoodType)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
                >
                  <option value="Cooked Meal">Cooked Meal</option>
                  <option value="Bakery">Bakery Items</option>
                  <option value="Packaged">Packaged Goods</option>
                  <option value="Snacks">Snacks / Finger Food</option>
                  <option value="Beverage">Fresh Beverages</option>
                </select>
              </div>

              <div>
                <label className="block text-rose-200 font-medium mb-1">Dietary Classification</label>
                <select
                  value={dietary}
                  onChange={(e) => setDietary(e.target.value as DietaryType)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
                >
                  <option value="Veg">Vegetarian (Veg)</option>
                  <option value="Non-Veg">Non-Vegetarian</option>
                  <option value="Vegan">100% Vegan</option>
                  <option value="Halal">Halal Certified</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-rose-200 font-medium mb-1">Portions (Qty)</label>
                <input
                  type="number"
                  min="1"
                  value={portions}
                  onChange={(e) => setPortions(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-rose-200 font-medium mb-1">Shelf Life (Hours)</label>
                <input
                  type="number"
                  min="1"
                  max="24"
                  value={shelfLifeHours}
                  onChange={(e) => setShelfLifeHours(parseInt(e.target.value) || 4)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-rose-200 font-medium mb-1">Retail Price (₹)</label>
                <input
                  type="number"
                  step="5"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(parseFloat(e.target.value) || 10)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-rose-200 font-medium mb-1">Target Distribution Smart Stall Node</label>
              <select
                value={assignedStallId}
                onChange={(e) => setAssignedStallId(e.target.value)}
                className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2.5 text-rose-100 focus:outline-none focus:border-rose-600"
              >
                {stalls.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-rose-200 font-medium mb-1">Photo URL or Camera Snapshot</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={photoUrl}
                  onChange={(e) => setPhotoUrl(e.target.value)}
                  className="w-full bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2 text-rose-100 focus:outline-none focus:border-rose-600"
                />
                <button
                  type="button"
                  onClick={handleInspectFood}
                  disabled={inspecting || !foodName}
                  className="px-3 py-2 bg-[#18060a] hover:bg-[#280911] text-rose-300 rounded-xl font-bold border border-rose-800/60 flex items-center gap-1.5 whitespace-nowrap"
                >
                  {inspecting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Camera className="w-3.5 h-3.5 text-rose-400" />
                  )}
                  <span>AI Inspect</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-rose-800 via-rose-700 to-rose-600 hover:from-rose-700 hover:to-rose-500 text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-rose-950/50"
            >
              Publish Surplus Batch to Network
            </button>
          </form>
        </div>

        {/* Right: AI Food Inspection Results */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#0e0306] border border-rose-900/50 p-5 rounded-2xl shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-rose-400" />
                AI Visual Safety Guard (Gemini 3.6 Flash)
              </h3>
              <span className="text-[10px] font-mono text-rose-300 bg-rose-950 px-2 py-0.5 rounded border border-rose-800">
                ACTIVE
              </span>
            </div>

            {inspecting ? (
              <div className="py-8 text-center text-rose-300/70 space-y-2">
                <Loader2 className="w-8 h-8 text-rose-400 animate-spin mx-auto" />
                <p className="text-xs font-semibold text-rose-300">
                  Analyzing packaging integrity & temperature parameters...
                </p>
              </div>
            ) : aiInspectionResult ? (
              <div className="space-y-3 text-xs bg-[#050102] p-4 rounded-xl border border-[#2d0910]">
                <div className="flex items-center justify-between">
                  <span className="text-rose-300/70">AI Safety Score:</span>
                  <span className="font-extrabold text-rose-400 text-sm">
                    {aiInspectionResult.safetyScore} / 100 Grade A
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-rose-300/70">Packaging Seal:</span>
                  <span className="font-bold text-rose-300">
                    {aiInspectionResult.packagingVerified ? '✓ Verified Sealed' : '⚠ Manual Check Required'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-rose-300/70">Suggested Dynamic Discount:</span>
                  <span className="font-bold text-amber-400">
                    {aiInspectionResult.suggestedDiscount}% OFF
                  </span>
                </div>

                <div className="pt-2 border-t border-[#2d0910] text-rose-200">
                  <p className="font-semibold text-rose-300/70">Notes:</p>
                  <p className="mt-0.5 text-rose-200">{aiInspectionResult.safetyNotes}</p>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-rose-300/70 text-xs bg-[#050102] p-4 rounded-xl border border-dashed border-[#2d0910] space-y-1">
                <Sparkles className="w-6 h-6 text-rose-400 mx-auto opacity-60" />
                <p className="text-rose-200 font-medium">No active visual inspection yet.</p>
                <p className="text-rose-400/50">
                  Click "AI Inspect" above to run Gemini visual hygiene & packaging checks.
                </p>
              </div>
            )}
          </div>

          {/* Quick Stats widget */}
          <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-2 text-xs">
            <h4 className="font-bold text-white">Donor Impact Summary</h4>
            <div className="flex justify-between text-rose-300/70 py-1 border-b border-[#2d0910]">
              <span>Active Listings</span>
              <span className="font-bold text-rose-100">{foodItems.length} batches</span>
            </div>
            <div className="flex justify-between text-rose-300/70 py-1 border-b border-[#2d0910]">
              <span>Meals Rescued</span>
              <span className="font-bold text-rose-400">{impactMetrics.mealsRescued} meals</span>
            </div>
            <div className="flex justify-between text-rose-300/70 py-1">
              <span>Total ESG Impact Score</span>
              <span className="font-bold text-amber-400">{impactMetrics.esgScore} / 100</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
