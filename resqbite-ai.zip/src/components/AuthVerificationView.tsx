import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AuthUser, UserPersona } from '../types';
import {
  ShieldCheck,
  User,
  Building2,
  Bike,
  Store,
  CheckCircle2,
  AlertCircle,
  FileText,
  CreditCard,
  Phone,
  Mail,
  Lock,
  ArrowRight,
  Upload,
  X,
  Sparkles,
  QrCode,
  BadgeCheck
} from 'lucide-react';

interface AuthVerificationViewProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthUser | null;
  onLogin: (user: AuthUser) => void;
  onVerify: (verificationDetails: AuthUser['verificationDetails']) => void;
  initialRole?: UserPersona;
}

export const AuthVerificationView: React.FC<AuthVerificationViewProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogin,
  onVerify,
  initialRole = 'consumer',
}) => {
  const [mode, setMode] = useState<'signin' | 'signup' | 'verify'>(
    currentUser ? (currentUser.isVerified ? 'verify' : 'verify') : 'signin'
  );

  const [selectedRole, setSelectedRole] = useState<UserPersona>(
    currentUser?.role || initialRole
  );

  // Form Fields
  const [email, setEmail] = useState(currentUser?.email || 'aarav.sharma@sit.edu');
  const [phone, setPhone] = useState(currentUser?.phone || '+91 98765 43210');
  const [password, setPassword] = useState('••••••••');
  const [name, setName] = useState(currentUser?.name || 'Aarav Sharma');

  // OTP Simulation State
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);

  // Verification Form Fields
  const [studentId, setStudentId] = useState(currentUser?.verificationDetails?.studentId || 'SIT-2024-8841');
  const [university, setUniversity] = useState(currentUser?.verificationDetails?.university || 'State Institute of Technology');
  const [upiId, setUpiId] = useState(currentUser?.verificationDetails?.upiId || 'aarav@upi');

  const [fssaiLicense, setFssaiLicense] = useState(currentUser?.verificationDetails?.fssaiLicense || '11522001000842');
  const [gstin, setGstin] = useState(currentUser?.verificationDetails?.gstin || '27AABCU9603R1ZM');

  const [stallCode, setStallCode] = useState(currentUser?.verificationDetails?.stallCode || 'STALL-STATION-B');

  const [idPhotoName, setIdPhotoName] = useState<string>('student_id_card_scan.jpg');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  if (!isOpen) return null;

  const handleSendOTP = () => {
    setOtpSent(true);
    setSuccessMessage('✓ 6-digit OTP code sent to your mobile & email!');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.length === 6 || otpCode === '123456' || otpCode === '') {
      setOtpVerified(true);
      setSuccessMessage('✓ Phone & Email Verified via Secure OTP!');
      setTimeout(() => {
        setSuccessMessage('');
        if (mode === 'signup') {
          setMode('verify');
        }
      }, 1000);
    }
  };

  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const mockUser: AuthUser = {
        id: currentUser?.id || `user-${Date.now()}`,
        name: name || (selectedRole === 'donor' ? 'Royal Spice Kitchen' : 'Aarav Sharma'),
        email,
        phone,
        role: selectedRole,
        isVerified: true,
        verifiedAt: new Date().toLocaleDateString(),
        verificationDetails: {
          studentId,
          university,
          upiId,
          fssaiLicense,
          gstin,
          stallCode,
          idCardPhotoUrl: idPhotoName,
        },
      };

      onLogin(mockUser);
      setIsSubmitting(false);
      setSuccessMessage('✓ Successfully signed in & verified!');
      setTimeout(() => {
        setSuccessMessage('');
        onClose();
      }, 1000);
    }, 800);
  };

  const handleVerificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const details = {
        studentId,
        university,
        upiId,
        fssaiLicense,
        gstin,
        stallCode,
        idCardPhotoUrl: idPhotoName,
      };

      onVerify(details);
      setIsSubmitting(false);
      setSuccessMessage('✓ Verification documents approved! Badge issued.');
      setTimeout(() => {
        setSuccessMessage('');
        onClose();
      }, 1200);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-[#0e0306] border border-rose-900/60 rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden my-8 text-slate-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] p-6 border-b border-[#2d0910] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-800 to-rose-600 text-white font-black flex items-center justify-center shadow-lg shadow-rose-950/50">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                {mode === 'verify' ? 'Identity & Compliance Verification' : mode === 'signup' ? 'Create ResQBite Account' : 'Sign In to ResQBite'}
                <Sparkles className="w-4 h-4 text-amber-400" />
              </h2>
              <p className="text-xs text-rose-300/60">
                {mode === 'verify'
                  ? 'Verify FSSAI license, Student ID, or UPI for instant payouts & subsidized access'
                  : 'Access AI-powered surplus food logistics & marketplace'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-rose-300/60 hover:text-white p-2 rounded-xl bg-[#050102] border border-[#2d0910] hover:border-rose-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode & Persona Selector */}
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-center gap-2 p-1 bg-[#050102] rounded-2xl border border-[#2d0910] relative">
            {[
              { id: 'signin', label: 'Sign In' },
              { id: 'signup', label: 'Sign Up' },
              { id: 'verify', label: 'Verify Badges' },
            ].map((tab) => {
              const isActive = mode === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setMode(tab.id as any)}
                  className={`relative flex-1 py-2 text-xs font-bold rounded-xl transition-colors z-10 ${
                    isActive ? 'text-white font-bold' : 'text-rose-400/50 hover:text-white'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="authModePill"
                      className="absolute inset-0 bg-rose-700 rounded-xl shadow-md z-0"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Role Choice Cards */}
          <div>
            <label className="block text-xs font-bold text-rose-300/80 mb-2">Select User Role Profile:</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <button
                type="button"
                onClick={() => setSelectedRole('consumer')}
                className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                  selectedRole === 'consumer'
                    ? 'bg-rose-950/80 border-rose-500 text-white shadow-lg'
                    : 'bg-[#050102] border-[#2d0910] text-rose-300/60 hover:border-rose-800'
                }`}
              >
                <User className="w-5 h-5 text-rose-400 mb-2" />
                <div>
                  <span className="font-extrabold text-xs block">Consumer</span>
                  <span className="text-[10px] text-rose-300/50">Discounted Meals</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('student')}
                className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                  selectedRole === 'student'
                    ? 'bg-amber-950/80 border-amber-500 text-white shadow-lg'
                    : 'bg-[#050102] border-[#2d0910] text-rose-300/60 hover:border-rose-800'
                }`}
              >
                <Bike className="w-5 h-5 text-amber-400 mb-2" />
                <div>
                  <span className="font-extrabold text-xs block">Student Gig</span>
                  <span className="text-[10px] text-rose-300/50">Deliveries & Shifts</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('donor')}
                className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                  selectedRole === 'donor'
                    ? 'bg-rose-950/80 border-rose-500 text-white shadow-lg'
                    : 'bg-[#050102] border-[#2d0910] text-rose-300/60 hover:border-rose-800'
                }`}
              >
                <Store className="w-5 h-5 text-rose-400 mb-2" />
                <div>
                  <span className="font-extrabold text-xs block">Restaurant</span>
                  <span className="text-[10px] text-rose-300/50">ESG & Surplus Food</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedRole('operator')}
                className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                  selectedRole === 'operator'
                    ? 'bg-rose-950/80 border-rose-500 text-white shadow-lg'
                    : 'bg-[#050102] border-[#2d0910] text-rose-300/60 hover:border-rose-800'
                }`}
              >
                <Building2 className="w-5 h-5 text-rose-400 mb-2" />
                <div>
                  <span className="font-extrabold text-xs block">Smart Stall</span>
                  <span className="text-[10px] text-rose-300/50">Node Operator</span>
                </div>
              </button>
            </div>
          </div>

          {/* Alert / Success Toast */}
          {successMessage && (
            <div className="p-3 bg-emerald-950 border border-emerald-500 text-emerald-300 text-xs font-bold rounded-2xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* SIGN IN & SIGN UP FORMS */}
          {(mode === 'signin' || mode === 'signup') && (
            <form onSubmit={handleSignInSubmit} className="space-y-4 text-xs">
              {mode === 'signup' && (
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Full Name / Business Title</label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Aarav Sharma or Royal Spice Kitchen"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Phone (for OTP)</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                    <input
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Mobile OTP Verification Simulation */}
              {mode === 'signup' && (
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-300">2-Factor Phone Verification</span>
                    {!otpSent ? (
                      <button
                        type="button"
                        onClick={handleSendOTP}
                        className="px-3 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg font-bold text-[11px]"
                      >
                        Send OTP SMS
                      </button>
                    ) : (
                      <span className="text-[10px] text-emerald-400 font-mono">OTP Sent to {phone}</span>
                    )}
                  </div>

                  {otpSent && (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={6}
                        placeholder="Enter 6-digit OTP (e.g. 123456)"
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-center font-mono text-emerald-300 text-sm focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        onClick={handleVerifyOTP}
                        className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs"
                      >
                        Verify OTP
                      </button>
                    </div>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-2xl shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
              >
                <span>{mode === 'signin' ? 'Sign In & Access Portal' : 'Create Account & Continue'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* VERIFICATION FORM */}
          {mode === 'verify' && (
            <form onSubmit={handleVerificationSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-slate-950 border border-emerald-500/30 rounded-2xl flex items-center gap-3">
                <BadgeCheck className="w-6 h-6 text-emerald-400 flex-shrink-0" />
                <div className="text-[11px]">
                  <span className="font-bold text-white block">Official Verified Badge System</span>
                  <span className="text-slate-400">
                    Submit authentic institutional details to unlock student shift booking, instant UPI cashouts, and FSSAI tax deductions.
                  </span>
                </div>
              </div>

              {/* Student Specific Verification */}
              {selectedRole === 'student' && (
                <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                    <Bike className="w-4 h-4" /> Student Volunteer & Gig Verification
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">University / College Name</label>
                      <input
                        type="text"
                        required
                        value={university}
                        onChange={(e) => setUniversity(e.target.value)}
                        placeholder="State Institute of Technology"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Student Roll / ID Card No.</label>
                      <input
                        type="text"
                        required
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        placeholder="SIT-2024-8841"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 font-mono text-amber-300 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Connected UPI ID (Instant Earnings Payouts)</label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                      <input
                        type="text"
                        required
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        placeholder="aarav@upi or 9876543210@paytm"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-emerald-300 font-mono focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Upload Student ID Photo / Scan</label>
                    <div className="flex items-center gap-2 bg-slate-900 border border-dashed border-slate-700 p-3 rounded-xl">
                      <Upload className="w-4 h-4 text-amber-400" />
                      <span className="text-slate-300 font-mono text-[11px] flex-1">{idPhotoName}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setIdPhotoName(`student_id_${Date.now().toString().slice(-4)}.jpg`);
                          alert('Selected student ID card document for automated OCR scanning!');
                        }}
                        className="px-2.5 py-1 bg-amber-500 text-slate-950 font-bold rounded-lg text-[10px]"
                      >
                        Choose File
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Restaurant / Donor Specific Verification */}
              {selectedRole === 'donor' && (
                <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <h4 className="font-bold text-teal-400 flex items-center gap-1.5">
                    <Store className="w-4 h-4" /> Food Safety (FSSAI) & GST Compliance
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1">FSSAI License No. (14 digits)</label>
                      <input
                        type="text"
                        required
                        value={fssaiLicense}
                        onChange={(e) => setFssaiLicense(e.target.value)}
                        placeholder="11522001000842"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 font-mono text-teal-300 focus:outline-none focus:border-teal-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">GSTIN Number (for ESG Tax Credit)</label>
                      <input
                        type="text"
                        required
                        value={gstin}
                        onChange={(e) => setGstin(e.target.value)}
                        placeholder="27AABCU9603R1ZM"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 font-mono text-teal-300 focus:outline-none focus:border-teal-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Smart Stall Operator Specific Verification */}
              {selectedRole === 'operator' && (
                <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <h4 className="font-bold text-cyan-400 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4" /> Smart Stall Hardware Node Authorization
                  </h4>

                  <div>
                    <label className="block text-slate-400 mb-1">Physical Stall Node Code</label>
                    <input
                      type="text"
                      required
                      value={stallCode}
                      onChange={(e) => setStallCode(e.target.value)}
                      placeholder="STALL-STATION-B"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                </div>
              )}

              {/* Consumer Verification */}
              {selectedRole === 'consumer' && (
                <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <h4 className="font-bold text-emerald-400 flex items-center gap-1.5">
                    <User className="w-4 h-4" /> Commuter & Beneficiary Verification
                  </h4>

                  <div>
                    <label className="block text-slate-400 mb-1">Subsidized Meal Beneficiary Pass (Optional)</label>
                    <input
                      type="text"
                      value="PASS-BENEFICIARY-8821"
                      readOnly
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 font-mono text-emerald-300 focus:outline-none"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">
                      Enables $0 Subsidized Free Meal Token claims at all physical Smart Stalls.
                    </p>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-2xl shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Submit Verification & Issue Verified Badge</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
