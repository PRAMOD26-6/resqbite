import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Sparkles, Loader2, User, MessageSquare } from 'lucide-react';

interface EcoBiteBotProps {
  isOpen: boolean;
  onClose: () => void;
  persona: string;
}

interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
  time: string;
}

export const EcoBiteBot: React.FC<EcoBiteBotProps> = ({
  isOpen,
  onClose,
  persona,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'bot',
      text: "Hello! I'm EcoBite Bot, your AI surplus food assistant. Ask me to find cheap meals, assist with restaurant listings, guide volunteer shifts, or locate free meal stalls!",
      time: 'Just Now',
    },
  ]);
  const [inputMsg, setInputMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || inputMsg;
    if (!query.trim()) return;

    const userMsg: ChatMessage = {
      sender: 'user',
      text: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMsg('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query, persona }),
      });
      const data = await res.json();

      const botMsg: ChatMessage = {
        sender: 'bot',
        text: data.reply || 'I am ready to assist you with surplus food routing and Smart Stall information.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error('Chat error:', err);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    'Find hot veg meal under ₹50 near Railway Station',
    'How do restaurants claim ESG tax credits?',
    'Show my student volunteer payouts & shift schedule',
    'Locate nearest free food stall'
  ];

  return (
    <div className="fixed bottom-4 right-4 z-50 w-full max-w-sm sm:max-w-md bg-[#0e0306] border border-rose-900/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[520px] text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] p-4 border-b border-[#2d0910] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-rose-800 text-white font-bold flex items-center justify-center shadow-lg shadow-rose-950/50">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
              EcoBite Bot <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </h3>
            <span className="text-[10px] text-rose-300 font-mono">
              Powered by Gemini 3.6 Flash
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="text-rose-400/60 hover:text-white p-1 rounded-lg hover:bg-rose-950"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Message Stream */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-2 ${
              msg.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.sender === 'bot' && (
              <div className="w-6 h-6 rounded-full bg-rose-950 border border-rose-700 text-rose-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot className="w-3.5 h-3.5" />
              </div>
            )}

            <div
              className={`max-w-[80%] rounded-2xl p-3 leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-rose-700 text-white font-medium rounded-tr-none'
                  : 'bg-[#050102] border border-[#2d0910] text-rose-100 rounded-tl-none'
              }`}
            >
              <p>{msg.text}</p>
              <span className="text-[9px] opacity-60 block text-right mt-1 font-mono">
                {msg.time}
              </span>
            </div>

            {msg.sender === 'user' && (
              <div className="w-6 h-6 rounded-full bg-rose-950 text-rose-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-rose-300/60 text-xs py-2">
            <Loader2 className="w-4 h-4 text-rose-400 animate-spin" />
            <span>EcoBite Bot is thinking...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="p-2 bg-[#050102] border-t border-[#2d0910] flex gap-1.5 overflow-x-auto scrollbar-none">
        {quickPrompts.map((prompt) => (
          <button
            key={prompt}
            onClick={() => handleSend(prompt)}
            className="px-2.5 py-1 rounded-full bg-[#0e0306] border border-[#2d0910] hover:border-rose-700 text-[10px] text-rose-300/80 hover:text-white transition-all"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="p-3 bg-[#0e0306] border-t border-[#2d0910] flex items-center gap-2"
      >
        <input
          type="text"
          placeholder="Ask EcoBite AI..."
          value={inputMsg}
          onChange={(e) => setInputMsg(e.target.value)}
          className="flex-1 bg-[#050102] border border-[#2d0910] rounded-xl px-3 py-2 text-xs text-rose-100 placeholder-rose-400/40 focus:outline-none focus:border-rose-600"
        />
        <button
          type="submit"
          disabled={!inputMsg.trim() || loading}
          className="p-2 bg-rose-700 hover:bg-rose-600 disabled:opacity-50 text-white rounded-xl font-bold transition-all shadow-lg shadow-rose-950/50"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
