import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { FoodItem, SmartStall, StudentVolunteer, LogisticsTask } from '../types';
import {
  MapPin,
  Store,
  Bike,
  Building2,
  Filter,
  Navigation,
  Sparkles,
  Radio,
  Search,
  Maximize2,
  RefreshCw,
  Info,
  Layers,
  Thermometer,
  ShieldCheck,
  PackageCheck,
  ChevronRight,
  Zap
} from 'lucide-react';

interface InteractiveMapProps {
  foodItems: FoodItem[];
  stalls: SmartStall[];
  students: StudentVolunteer[];
  tasks: LogisticsTask[];
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  foodItems,
  stalls,
  students,
  tasks,
}) => {
  const [viewMode, setViewMode] = useState<'map' | 'mesh'>('map');
  const [selectedNode, setSelectedNode] = useState<{
    type: 'donor' | 'student' | 'stall';
    data: any;
  } | null>(null);

  const [filterDonors, setFilterDonors] = useState(true);
  const [filterStudents, setFilterStudents] = useState(true);
  const [filterStalls, setFilterStalls] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);

  // Default Center: Gadag District, Karnataka, India
  const defaultCenter: [number, number] = [15.4312, 75.6350];
  const defaultZoom = 12;

  // Aggregate Donors from foodItems
  const donorsMap = React.useMemo(() => {
    const map = new Map<string, { id: string; name: string; locationName: string; lat: number; lng: number; itemCount: number; totalPortions: number; items: FoodItem[] }>();
    foodItems.forEach((item) => {
      const existing = map.get(item.donorId);
      if (existing) {
        existing.itemCount += 1;
        existing.totalPortions += item.remainingPortions;
        existing.items.push(item);
      } else {
        map.set(item.donorId, {
          id: item.donorId,
          name: item.donorName,
          locationName: item.donorLocation.name,
          lat: item.donorLocation.lat,
          lng: item.donorLocation.lng,
          itemCount: 1,
          totalPortions: item.remainingPortions,
          items: [item]
        });
      }
    });
    return Array.from(map.values());
  }, [foodItems]);

  // Initialize and update Leaflet Map
  useEffect(() => {
    if (viewMode !== 'map' || !mapContainerRef.current) return;

    // Initialize Map if not already initialized
    if (!leafletMapRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: defaultZoom,
        zoomControl: false,
      });

      // Add Zoom Control at bottom right
      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // Dark Matter Map Tiles from CartoDB / OSM for a premium aesthetic
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      layerGroupRef.current = L.layerGroup().addTo(map);
      leafletMapRef.current = map;
    }

    const map = leafletMapRef.current;
    const layerGroup = layerGroupRef.current;

    if (!layerGroup) return;

    // Clear previous layers
    layerGroup.clearLayers();

    const bounds = L.latLngBounds([]);

    // 1. Render Donor Markers
    if (filterDonors) {
      donorsMap.forEach((donor) => {
        if (
          searchQuery &&
          !donor.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !donor.locationName.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return;
        }

        bounds.extend([donor.lat, donor.lng]);

        const iconHtml = `
          <div class="relative flex items-center justify-center group cursor-pointer">
            <div class="w-9 h-9 rounded-2xl bg-[#1f060b] border-2 border-rose-500 text-rose-300 flex items-center justify-center shadow-lg shadow-rose-950/80 transition-transform hover:scale-125">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2v0a2 2 0 0 1-2-2V7"/></svg>
            </div>
            <span class="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#0a0204]/90 text-rose-200 font-extrabold text-[10px] px-1.5 py-0.5 rounded border border-rose-800 shadow">
              ${donor.name.split(' ')[0]} (${donor.totalPortions}p)
            </span>
          </div>
        `;

        const customIcon = L.divIcon({
          html: iconHtml,
          className: 'custom-donor-icon',
          iconSize: [36, 36],
          iconAnchor: [18, 18],
        });

        const marker = L.marker([donor.lat, donor.lng], { icon: customIcon });
        marker.on('click', () => {
          setSelectedNode({ type: 'donor', data: donor });
        });
        layerGroup.addLayer(marker);
      });
    }

    // 2. Render Smart Stall Markers
    if (filterStalls) {
      stalls.forEach((stall) => {
        if (
          searchQuery &&
          !stall.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !stall.locationName.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return;
        }

        bounds.extend([stall.lat, stall.lng]);

        const totalStock = stall.vegCount + stall.nonVegCount + stall.bakeryCount + stall.beverageCount;

        const iconHtml = `
          <div class="relative flex items-center justify-center group cursor-pointer">
            <div class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-950 via-rose-900 to-rose-800 border-2 border-rose-400 text-white flex items-center justify-center shadow-xl shadow-rose-950/90 transition-transform hover:scale-125">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/></svg>
            </div>
            <span class="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#0a0204]/90 text-rose-100 font-bold text-[10px] px-1.5 py-0.5 rounded border border-rose-700 shadow">
              ${stall.name} (${totalStock} meals)
            </span>
          </div>
        `;

        const customIcon = L.divIcon({
          html: iconHtml,
          className: 'custom-stall-icon',
          iconSize: [40, 40],
          iconAnchor: [20, 20],
        });

        const marker = L.marker([stall.lat, stall.lng], { icon: customIcon });
        marker.on('click', () => {
          setSelectedNode({ type: 'stall', data: stall });
        });
        layerGroup.addLayer(marker);
      });
    }

    // 3. Render Student Volunteer Markers
    if (filterStudents) {
      students.forEach((student) => {
        if (
          searchQuery &&
          !student.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !student.university.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          return;
        }

        bounds.extend([student.lat, student.lng]);

        const iconHtml = `
          <div class="relative flex items-center justify-center group cursor-pointer animate-pulse">
            <div class="w-9 h-9 rounded-full bg-amber-500/20 border-2 border-amber-400 text-amber-300 flex items-center justify-center shadow-lg shadow-amber-950/80 transition-transform hover:scale-125">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18.5" cy="17.5" r="3.5"/><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="15" cy="5" r="1"/><path d="M12 17.5V14l-3-3 4-3 2 3h2"/></svg>
            </div>
            <span class="absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#0a0204]/90 text-amber-300 font-bold text-[10px] px-1.5 py-0.5 rounded border border-amber-500/40 shadow">
              ${student.name.split(' ')[0]} (${student.transitMode})
            </span>
          </div>
        `;

        const customIcon = L.divIcon({
          html: iconHtml,
          className: 'custom-student-icon',
          iconSize: [36, 36],
          iconAnchor: [18, 18],
        });

        const marker = L.marker([student.lat, student.lng], { icon: customIcon });
        marker.on('click', () => {
          setSelectedNode({ type: 'student', data: student });
        });
        layerGroup.addLayer(marker);
      });
    }

    // 4. Render Active Delivery Routes (Polylines from Donor -> Volunteer -> Stall)
    tasks.forEach((task) => {
      if (task.donorLat && task.donorLng && task.stallLat && task.stallLng) {
        // Line from Donor to Stall
        const polyline = L.polyline(
          [
            [task.donorLat, task.donorLng],
            [task.stallLat, task.stallLng],
          ],
          {
            color: '#e12d4f',
            weight: 3,
            dashArray: '6, 8',
            opacity: 0.85,
          }
        );

        polyline.bindTooltip(`Route: ${task.foodName} (Payout: ₹${task.totalPayout})`, {
          sticky: true,
          className: 'bg-[#0a0204] text-rose-200 text-xs border border-rose-800 rounded p-1 font-mono',
        });

        layerGroup.addLayer(polyline);
      }
    });

    // Auto-fit bounds if we have valid markers
    if (bounds.isValid() && !searchQuery) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    }
  }, [viewMode, filterDonors, filterStalls, filterStudents, searchQuery, donorsMap, stalls, students, tasks]);

  // Center preset helper
  const handleCenterPreset = (preset: 'all' | 'stalls' | 'donors') => {
    if (!leafletMapRef.current) return;
    const map = leafletMapRef.current;

    if (preset === 'all') {
      map.setView(defaultCenter, defaultZoom);
    } else if (preset === 'stalls' && stalls.length > 0) {
      const bounds = L.latLngBounds(stalls.map((s) => [s.lat, s.lng]));
      map.fitBounds(bounds, { padding: [40, 40] });
    } else if (preset === 'donors' && donorsMap.length > 0) {
      const bounds = L.latLngBounds(donorsMap.map((d) => [d.lat, d.lng]));
      map.fitBounds(bounds, { padding: [40, 40] });
    }
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 rounded-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800 mb-1">
            <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>Karnataka • Gadag District Hyper-Local Network</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2">
            Gadag District Live Location Map
            <Sparkles className="w-5 h-5 text-amber-400" />
          </h1>
          <p className="text-xs text-rose-300/60 mt-0.5">
            Geospatial tracking of surplus donors, Smart Stalls, and active student gig routes across Gadag, Betageri, Ron, Mundargi, and Shirahatti.
          </p>
        </div>

        {/* View Switcher & Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-[#050102] p-1 rounded-xl border border-[#2d0910]">
            <button
              onClick={() => setViewMode('map')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewMode === 'map'
                  ? 'bg-rose-700 text-white shadow'
                  : 'text-rose-400/60 hover:text-white'
              }`}
            >
              <Navigation className="w-3.5 h-3.5" /> Real Location Map
            </button>
            <button
              onClick={() => setViewMode('mesh')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewMode === 'mesh'
                  ? 'bg-rose-700 text-white shadow'
                  : 'text-rose-400/60 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" /> Mesh Diagram
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl shadow-lg flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
        {/* Layer Filters */}
        <div className="flex items-center gap-2 flex-wrap text-xs font-bold">
          <span className="text-rose-300/60 text-[11px] uppercase tracking-wider font-mono mr-1">
            Toggle Nodes:
          </span>
          <button
            onClick={() => setFilterDonors(!filterDonors)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all ${
              filterDonors
                ? 'bg-rose-950 text-rose-200 border-rose-500 shadow'
                : 'bg-[#050102] text-rose-400/40 border-[#2d0910]'
            }`}
          >
            <Store className="w-3.5 h-3.5 text-rose-400" /> Donors ({donorsMap.length})
          </button>
          <button
            onClick={() => setFilterStalls(!filterStalls)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all ${
              filterStalls
                ? 'bg-rose-900/80 text-rose-100 border-rose-400 shadow'
                : 'bg-[#050102] text-rose-400/40 border-[#2d0910]'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-rose-300" /> Smart Stalls ({stalls.length})
          </button>
          <button
            onClick={() => setFilterStudents(!filterStudents)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all ${
              filterStudents
                ? 'bg-amber-950/80 text-amber-200 border-amber-500 shadow'
                : 'bg-[#050102] text-rose-400/40 border-[#2d0910]'
            }`}
          >
            <Bike className="w-3.5 h-3.5 text-amber-400" /> Student Gig ({students.length})
          </button>
        </div>

        {/* Search Input & Quick Center Presets */}
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-rose-400/60 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search map by venue name, area, or stall..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#050102] border border-[#2d0910] rounded-xl pl-9 pr-3 py-1.5 text-xs text-rose-100 placeholder-rose-400/40 focus:outline-none focus:border-rose-600"
            />
          </div>

          <button
            onClick={() => handleCenterPreset('all')}
            className="p-2 bg-[#050102] border border-[#2d0910] hover:border-rose-700 text-rose-300 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all"
            title="Reset Map Bounds"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Map View Container */}
      {viewMode === 'map' ? (
        <div className="relative w-full h-[540px] bg-[#050102] rounded-2xl border border-[#2d0910] overflow-hidden shadow-2xl">
          {/* Leaflet Map DOM Element */}
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* Quick Stats Overlay Card (Top Left) */}
          <div className="absolute top-4 left-4 z-10 bg-[#0e0306]/90 border border-rose-900/60 backdrop-blur-md rounded-2xl p-3 shadow-2xl text-xs space-y-2 hidden sm:block max-w-xs">
            <div className="flex items-center justify-between text-white font-extrabold pb-1.5 border-b border-[#2d0910]">
              <span className="flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" /> Active Network Metrics
              </span>
              <span className="text-[10px] text-rose-300 font-mono bg-rose-950 px-1.5 py-0.5 rounded">
                LIVE
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block text-[10px]">Active Donors</span>
                <span className="font-extrabold text-rose-300 text-sm">{donorsMap.length} Hubs</span>
              </div>
              <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block text-[10px]">Smart Stalls</span>
                <span className="font-extrabold text-rose-200 text-sm">{stalls.length} Stalls</span>
              </div>
              <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block text-[10px]">Gig Volunteers</span>
                <span className="font-extrabold text-amber-300 text-sm">{students.length} Active</span>
              </div>
              <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                <span className="text-rose-300/60 block text-[10px]">Active Deliveries</span>
                <span className="font-extrabold text-emerald-400 text-sm">{tasks.length} Routes</span>
              </div>
            </div>
          </div>

          {/* Map Legend Overlay (Bottom Left) */}
          <div className="absolute bottom-4 left-4 z-10 bg-[#0e0306]/90 border border-rose-900/60 backdrop-blur-md rounded-xl p-2.5 shadow-2xl text-[11px] flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-md bg-rose-600 inline-block border border-rose-400" />
              <span className="text-rose-200 font-medium">Donor Hub</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-md bg-rose-900 inline-block border border-rose-500" />
              <span className="text-rose-200 font-medium">Smart Stall</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block border border-amber-300" />
              <span className="text-amber-300 font-medium">Student Gig</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-0.5 border-t-2 border-dashed border-rose-500 inline-block" />
              <span className="text-rose-300 font-medium">Delivery Route</span>
            </div>
          </div>

          {/* Selected Node Details Side Panel / Popup Drawer */}
          {selectedNode && (
            <div className="absolute bottom-4 right-4 z-20 w-80 bg-[#0e0306]/95 border border-rose-800 p-4 rounded-2xl shadow-2xl backdrop-blur-md space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-[#2d0910] pb-2">
                <div className="flex items-center gap-2">
                  {selectedNode.type === 'donor' && <Store className="w-4 h-4 text-rose-400" />}
                  {selectedNode.type === 'stall' && <Building2 className="w-4 h-4 text-rose-300" />}
                  {selectedNode.type === 'student' && <Bike className="w-4 h-4 text-amber-400" />}
                  <span className="font-extrabold text-white text-sm truncate max-w-[180px]">
                    {selectedNode.data.name}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedNode(null)}
                  className="text-rose-400/60 hover:text-white p-1 font-bold"
                >
                  ✕
                </button>
              </div>

              {/* Donor Details */}
              {selectedNode.type === 'donor' && (
                <div className="space-y-2">
                  <p className="text-rose-300/70 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-400" /> {selectedNode.data.locationName}
                  </p>
                  <div className="bg-[#050102] p-2.5 rounded-xl border border-[#2d0910] space-y-1">
                    <div className="flex justify-between font-bold text-white">
                      <span>Available Surplus:</span>
                      <span className="text-rose-400">{selectedNode.data.totalPortions} Portions</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-rose-300/60">
                      <span>Active Food Listings:</span>
                      <span>{selectedNode.data.itemCount} Items</span>
                    </div>
                  </div>
                  {selectedNode.data.items?.[0] && (
                    <div className="p-2 rounded-xl bg-rose-950/40 border border-rose-900/50 text-[11px] space-y-1">
                      <span className="font-extrabold text-white block">
                        Featured: {selectedNode.data.items[0].foodName}
                      </span>
                      <div className="flex justify-between text-rose-300/80">
                        <span>Price: ₹{selectedNode.data.items[0].currentPrice} ({selectedNode.data.items[0].discountPercent}% OFF)</span>
                        <span className="text-amber-400">TTI: {selectedNode.data.items[0].ttiTemperature}°C</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Stall Details */}
              {selectedNode.type === 'stall' && (
                <div className="space-y-2">
                  <p className="text-rose-300/70 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-rose-400" /> {selectedNode.data.locationName}
                  </p>
                  <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                    <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                      <span className="text-rose-300/60 block text-[10px]">Chilled Bay</span>
                      <span className="font-bold text-cyan-400">{selectedNode.data.chilledTemp}°C</span>
                    </div>
                    <div className="bg-[#050102] p-2 rounded-xl border border-[#2d0910]">
                      <span className="text-rose-300/60 block text-[10px]">Hot Box Bay</span>
                      <span className="font-bold text-amber-400">{selectedNode.data.hotBoxTemp}°C</span>
                    </div>
                  </div>
                  <div className="bg-[#050102] p-2.5 rounded-xl border border-[#2d0910] space-y-1">
                    <div className="flex justify-between font-bold text-white">
                      <span>Available Stock:</span>
                      <span className="text-rose-300">
                        {selectedNode.data.vegCount + selectedNode.data.nonVegCount + selectedNode.data.bakeryCount + selectedNode.data.beverageCount} / {selectedNode.data.capacity}
                      </span>
                    </div>
                    <div className="flex justify-between text-[11px] text-rose-300/60">
                      <span>Operator:</span>
                      <span className="text-rose-200">{selectedNode.data.activeOperatorName}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Student Details */}
              {selectedNode.type === 'student' && (
                <div className="space-y-2">
                  <p className="text-rose-300/70 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> {selectedNode.data.university}
                  </p>
                  <div className="bg-[#050102] p-2.5 rounded-xl border border-[#2d0910] space-y-1">
                    <div className="flex justify-between text-[11px] text-rose-300/80">
                      <span>Transit Mode:</span>
                      <span className="font-bold text-amber-300">{selectedNode.data.transitMode}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-rose-300/80">
                      <span>Meals Rescued:</span>
                      <span className="font-bold text-white">{selectedNode.data.mealsRescuedCount} meals</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-rose-300/80">
                      <span>Carbon Saved:</span>
                      <span className="font-bold text-emerald-400">{selectedNode.data.carbonSavedKg} kg CO2e</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* Structural Mesh View */
        <div className="relative w-full h-[500px] bg-[#050102] rounded-2xl border border-[#2d0910] overflow-hidden shadow-2xl p-6">
          <div
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(#e11d48 1px, transparent 1px)`,
              backgroundSize: '28px 28px',
            }}
          />

          <div className="relative z-10 flex flex-col h-full justify-between space-y-6">
            <div className="flex items-center justify-between border-b border-[#2d0910] pb-3">
              <span className="text-xs font-mono text-rose-300 uppercase tracking-widest flex items-center gap-2">
                <Layers className="w-4 h-4 text-rose-400" /> Structural Supply & Demand Mesh Diagram
              </span>
              <span className="text-xs text-rose-300/60 font-mono">
                Nodes Connected: {donorsMap.length + stalls.length + students.length}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-auto">
              {/* Column 1: Donors */}
              <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-3">
                <h3 className="text-xs font-bold text-rose-300 flex items-center gap-2 border-b border-[#2d0910] pb-2">
                  <Store className="w-4 h-4 text-rose-400" /> Donors ({donorsMap.length})
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {donorsMap.map((donor) => (
                    <div
                      key={donor.id}
                      onClick={() => setSelectedNode({ type: 'donor', data: donor })}
                      className="p-2.5 rounded-xl bg-[#050102] border border-[#2d0910] hover:border-rose-600 cursor-pointer transition-all flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{donor.name}</span>
                        <span className="text-[10px] text-rose-300/60">{donor.locationName}</span>
                      </div>
                      <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-950 px-2 py-0.5 rounded">
                        {donor.totalPortions}p
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Column 2: Student Logistics Transit */}
              <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-3">
                <h3 className="text-xs font-bold text-amber-300 flex items-center gap-2 border-b border-[#2d0910] pb-2">
                  <Bike className="w-4 h-4 text-amber-400" /> Student Gig Logistics ({students.length})
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {students.map((student) => (
                    <div
                      key={student.id}
                      onClick={() => setSelectedNode({ type: 'student', data: student })}
                      className="p-2.5 rounded-xl bg-[#050102] border border-[#2d0910] hover:border-amber-500 cursor-pointer transition-all flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{student.name}</span>
                        <span className="text-[10px] text-amber-300/70">{student.transitMode}</span>
                      </div>
                      <span className="text-[10px] font-mono font-bold text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded">
                        {student.mealsRescuedCount} rescued
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Column 3: Smart Stalls */}
              <div className="bg-[#0e0306] border border-[#2d0910] p-4 rounded-2xl space-y-3">
                <h3 className="text-xs font-bold text-rose-200 flex items-center gap-2 border-b border-[#2d0910] pb-2">
                  <Building2 className="w-4 h-4 text-rose-300" /> Demand Smart Stalls ({stalls.length})
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {stalls.map((stall) => (
                    <div
                      key={stall.id}
                      onClick={() => setSelectedNode({ type: 'stall', data: stall })}
                      className="p-2.5 rounded-xl bg-[#050102] border border-[#2d0910] hover:border-rose-500 cursor-pointer transition-all flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{stall.name}</span>
                        <span className="text-[10px] text-rose-300/60">{stall.locationName}</span>
                      </div>
                      <span className="text-[10px] font-mono font-bold text-rose-300 bg-rose-900 px-2 py-0.5 rounded">
                        {stall.vegCount + stall.nonVegCount + stall.bakeryCount + stall.beverageCount} meals
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
