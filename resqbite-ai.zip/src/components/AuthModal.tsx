import React, { useState } from 'react';
import { AuthUser, UserPersona } from '../types';
import {
  X,
  UserCheck,
  ShieldCheck,
  Building2,
  Bike,
  Store,
  ShoppingBag,
  Smartphone,
  Mail,
  Lock,
  ArrowRight,
  CheckCircle2,
  FileCheck,
  Upload,
  Sparkles,
  AlertCircle,
  RefreshCw,
  Award,
  CreditCard,
  Key
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: AuthUser | null;
  onSignInSuccess: (user: AuthUser) => void;
  initialRole?: UserPersona;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSignInSuccess,
  initialRole = 'consumer',
}) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const [step, setStep] = useState<'credentials' | 'verification' | 'success'>('credentials');
  
  // Form fields
  const [role, setRole] = useState<UserPersona>(initialRole);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  
  // Verification details
  const [studentId, setStudentId] = useState('SIT-2024-8841');
  const [university, setUniversity] = useState('VJTI Autonomous Institute, Mumbai');
  const [upiId, setUpiId] = useState('aarav@okaxis');
  const [fssaiLicense, setFssaiLicense] = useState('11521001000452');
  const [gstin, setGstin] = useState('27AABCR1234H1Z0');
  const [stallCode, setStallCode] = useState('STALL-MUM-001');
  
  // OTP state
  const [otp, setOtp] = useState(['5', '8', '2', '9', '1', '0']);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(30);
  const [idCardUploaded, setIdCardUploaded] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSendOtp = () => {
    if (!phone && !email) {
      setErrorMsg('Please enter a valid phone number or email address.');
      return;
    }
    setErrorMsg('');
    setOtpSent(true);
    setOtpTimer(30);
    // start interval countdown
    const interval = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleNextToVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || (!email && !phone)) {
      setErrorMsg('Please fill in your name and contact details.');
      return;
    }
    setErrorMsg('');
    setStep('verification');
    if (!otpSent) {
      handleSendOtp();
    }
  };

  const handleCompleteVerification = () => {
    setIsVerifyingOtp(true);
    setErrorMsg('');

    setTimeout(() => {
      setIsVerifyingOtp(false);
      
      const newAuthUser: AuthUser = {
        id: `user-${Date.now()}`,
        name: name || (role === 'donor' ? 'Royal Spicy Bistro' : 'Aarav Sharma'),
        email: email || 'aarav.sharma@vjti.ac.in',
        phone: phone || '+91 98200 12345',
        role,
        isVerified: true,
        verifiedAt: new Date().toISOString(),
        avatarUrl: role === 'student' ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200' : undefined,
        verificationDetails: {
          studentId: role === 'student' || role === 'consumer' ? studentId : undefined,
          university: role === 'student' || role === 'consumer' ? university : undefined,
          upiId: role === 'student' ? upiId : undefined,
          fssaiLicense: role === 'donor' ? fssaiLicense : undefined,
          gstin: role === 'donor' ? gstin : undefined,
          stallCode: role === 'operator' ? stallCode : undefined,
          idCardPhotoUrl: idCardUploaded ? 'verified_card.jpg' : undefined,
        },
      };

      setStep('success');
      setTimeout(() => {
        onSignInSuccess(newAuthUser);
        onClose();
      }, 1500);
    }, 1200);
  };

  const handleDirectSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email && !phone) {
      setErrorMsg('Please enter email/phone to sign in');
      return;
    }
    setIsVerifyingOtp(true);
    setTimeout(() => {
      setIsVerifyingOtp(false);
      const existingUser: AuthUser = {
        id: 'user-default',
        name: name || (email.includes('donor') ? 'Royal Spicy Bistro' : 'Aarav Sharma'),
        email: email || 'aarav.sharma@vjti.ac.in',
        phone: phone || '+91 98200 12345',
        role,
        isVerified: true,
        verifiedAt: new Date().toISOString(),
        verificationDetails: {
          studentId: 'SIT-2024-8841',
          university: 'VJTI Autonomous Institute, Mumbai',
          fssaiLicense: '11521001000452',
          upiId: 'aarav@okaxis',
        },
      };
      onSignInSuccess(existingUser);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 p-0.5 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                ResQBite Authentication & Verification
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Instant Verification
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Verify your identity for subsidized meals, gig payouts, or donor ESG credits
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation Bar: Sign In vs Sign Up toggle */}
        <div className="px-6 pt-4 pb-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => {
                setAuthMode('signup');
                setStep('credentials');
              }}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                authMode === 'signup'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign Up & Verify
            </button>
            <button
              onClick={() => {
                setAuthMode('signin');
                setStep('credentials');
              }}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                authMode === 'signin'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
          </div>

          {/* Progress Indicator */}
          {authMode === 'signup' && (
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className={`px-2 py-0.5 rounded ${step === 'credentials' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-500'}`}>
                1. Account
              </span>
              <span>&rarr;</span>
              <span className={`px-2 py-0.5 rounded ${step === 'verification' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-500'}`}>
                2. Verification
              </span>
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {errorMsg && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-2 text-xs text-red-400">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* STEP SUCCESS */}
          {step === 'success' && (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto text-emerald-400 animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-white">Identity Verified Successfully!</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Your profile has been authenticated with official credentials. Accessing your custom persona dashboard...
              </p>
            </div>
          )}

          {/* SIGN IN FORM */}
          {authMode === 'signin' && step !== 'success' && (
            <form onSubmit={handleDirectSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Select Role / Account Persona
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('consumer')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'consumer'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Buyer / Student</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('student')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'student'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Bike className="w-4 h-4" />
                    <span>Gig Volunteer</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('donor')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'donor'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>Restaurant</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('operator')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'operator'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Stall Operator</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Phone Number or Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={email || phone}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setPhone(e.target.value);
                    }}
                    placeholder="+91 98200 12345 or user@vjti.ac.in"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Password or Passcode
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isVerifyingOtp}
                  className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 hover:from-emerald-400 hover:to-teal-400 transition-all shadow-lg shadow-emerald-500/20"
                >
                  {isVerifyingOtp ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Signing In...
                    </>
                  ) : (
                    <>
                      Sign In & Access Account
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    // Demo auto fill credentials
                    setName('Aarav Sharma');
                    setEmail('aarav.sharma@vjti.ac.in');
                    setPhone('+91 98200 12345');
                    setPassword('demo1234');
                  }}
                  className="text-xs text-emerald-400 hover:underline font-mono"
                >
                  [Demo] Fill Sample Verified Credentials
                </button>
              </div>
            </form>
          )}

          {/* SIGN UP STEP 1: CREDENTIALS */}
          {authMode === 'signup' && step === 'credentials' && (
            <form onSubmit={handleNextToVerification} className="space-y-4">
              {/* Persona Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Select User Role / Persona
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('consumer')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'consumer'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Buyer / Student</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('student')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'student'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Bike className="w-4 h-4" />
                    <span>Gig Volunteer</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('donor')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'donor'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>Restaurant</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('operator')}
                    className={`p-2.5 rounded-xl border text-left flex flex-col items-center justify-center gap-1 text-xs transition-all ${
                      role === 'operator'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Stall Operator</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name / Organization Name
                </label>
                <div className="relative">
                  <UserCheck className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={
                      role === 'donor'
                        ? 'Royal Spicy Bistro'
                        : role === 'operator'
                        ? 'Central Station Operator Hub'
                        : 'Aarav Sharma'
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mobile Number (for OTP)
                  </label>
                  <div className="relative">
                    <Smartphone className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98200 12345"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="aarav.sharma@vjti.ac.in"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Create Security Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 hover:from-emerald-400 hover:to-cyan-400 transition-all shadow-lg shadow-emerald-500/20"
                >
                  Proceed to Verification Step
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* SIGN UP STEP 2: VERIFICATION PAGE */}
          {authMode === 'signup' && step === 'verification' && (
            <div className="space-y-5">
              {/* Verification Header Badge */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3">
                <Award className="w-6 h-6 text-emerald-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-emerald-300">
                    {role === 'consumer' || role === 'student'
                      ? 'Student & Beneficiary Verification'
                      : role === 'donor'
                      ? 'FSSAI Food Safety & Tax Audit Verification'
                      : 'Smart Stall Authorized Personnel Verification'}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Provide credentials to unlock subsidized meals, free tokens, or automated tax receipts.
                  </p>
                </div>
              </div>

              {/* ROLE SPECIFIC VERIFICATION FIELDS */}
              {(role === 'student' || role === 'consumer') && (
                <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-cyan-400" />
                    University / Student Credentials
                  </h5>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        College / University Name
                      </label>
                      <input
                        type="text"
                        value={university}
                        onChange={(e) => setUniversity(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        Student Roll No / ID Card Number
                      </label>
                      <input
                        type="text"
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:border-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  {role === 'student' && (
                    <div>
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        UPI ID (For Shift Earnings & Task Payouts)
                      </label>
                      <input
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-emerald-400 font-mono focus:border-emerald-500"
                        placeholder="username@upi"
                      />
                    </div>
                  )}

                  {/* ID Card Upload Simulation */}
                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">
                      Upload Student ID / Aadhaar Scan (Optional Verification)
                    </label>
                    <button
                      type="button"
                      onClick={() => setIdCardUploaded(!idCardUploaded)}
                      className={`w-full py-2.5 px-3 rounded-xl border text-xs flex items-center justify-center gap-2 transition-all ${
                        idCardUploaded
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold'
                          : 'border-slate-800 bg-slate-900 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {idCardUploaded ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          Student ID Card Uploaded & OCR Scanned!
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4" />
                          Click to Attach ID Card Image / Document
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {role === 'donor' && (
                <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <FileCheck className="w-4 h-4 text-emerald-400" />
                    Food Safety & Tax Compliance Credentials
                  </h5>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">
                      14-Digit FSSAI License Number
                    </label>
                    <input
                      type="text"
                      value={fssaiLicense}
                      onChange={(e) => setFssaiLicense(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-amber-300 font-mono focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">
                      GSTIN Number (For 100% Tax Deduction Receipts)
                    </label>
                    <input
                      type="text"
                      value={gstin}
                      onChange={(e) => setGstin(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-mono focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}

              {role === 'operator' && (
                <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
                  <h5 className="text-xs font-bold text-white flex items-center gap-2">
                    <Key className="w-4 h-4 text-amber-400" />
                    Smart Stall Security Authorization
                  </h5>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-400 mb-1">
                      Assigned Smart Stall Code
                    </label>
                    <input
                      type="text"
                      value={stallCode}
                      onChange={(e) => setStallCode(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-cyan-300 font-mono focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}

              {/* 6-DIGIT OTP VERIFICATION BOX */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">
                    6-Digit SMS Verification Code
                  </span>
                  <span className="text-[11px] text-emerald-400 font-mono">
                    Sent to {phone || email || '+91 98200 12345'}
                  </span>
                </div>

                <div className="flex items-center justify-center gap-2">
                  {otp.map((digit, idx) => (
                    <input
                      key={idx}
                      type="text"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => {
                        const newOtp = [...otp];
                        newOtp[idx] = e.target.value;
                        setOtp(newOtp);
                      }}
                      className="w-10 h-12 bg-slate-900 border border-slate-800 rounded-xl text-center text-lg font-bold font-mono text-emerald-400 focus:outline-none focus:border-emerald-500"
                    />
                  ))}
                </div>

                <div className="flex items-center justify-between text-[11px] pt-1">
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={otpTimer > 0}
                    className={`font-mono ${
                      otpTimer > 0 ? 'text-slate-500 cursor-not-allowed' : 'text-emerald-400 hover:underline'
                    }`}
                  >
                    {otpTimer > 0 ? `Resend code in ${otpTimer}s` : 'Resend OTP Code'}
                  </button>
                  <span className="text-slate-500 font-mono">Auto-verification enabled</span>
                </div>
              </div>

              {/* Complete Action Button */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('credentials')}
                  className="px-4 py-3 bg-slate-950 text-slate-400 border border-slate-800 rounded-xl text-xs font-semibold hover:text-white hover:bg-slate-900 transition-all"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleCompleteVerification}
                  disabled={isVerifyingOtp}
                  className="flex-1 py-3 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 hover:from-emerald-400 hover:to-cyan-400 transition-all shadow-lg shadow-emerald-500/20"
                >
                  {isVerifyingOtp ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Verifying Identity Credentials...
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      Verify & Activate Account
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
