import React, { useState } from 'react';
import {
  Code2,
  Database,
  Cpu,
  Workflow,
  Sparkles,
  Terminal,
  CheckCircle2,
  Copy
} from 'lucide-react';

export const SystemArchitectureView: React.FC = () => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(label);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const dynamicPricingCode = `// AI Dynamic Pricing & Perishable Shelf-Life Decay Formula
function calculateDynamicPricing(originalPrice, prepTimestamp, shelfLifeHours) {
  const hoursElapsed = Math.max(0, (Date.now() - prepTimestamp) / (1000 * 3600));
  const remainingHours = Math.max(0, shelfLifeHours - hoursElapsed);
  const decayRatio = Math.min(1.0, hoursElapsed / shelfLifeHours);

  // Base discount 70% to 85% based on decay clock
  let discountPercent = Math.round(70 + decayRatio * 15);
  discountPercent = Math.min(88, Math.max(70, discountPercent));

  let currentPrice = +(originalPrice * (1 - discountPercent / 100)).toFixed(2);
  const isFreeTokenEligible = remainingHours <= 1.5 || discountPercent >= 85;

  return { currentPrice, discountPercent, isFreeTokenEligible, remainingHours };
}`;

  const routeMatchingCode = `// Geospatial Student Task Matching & Fare Calculation Algorithm
function matchOptimalStudentRoute(task, studentList) {
  return studentList
    .map(student => {
      const distKm = calculateHaversineDistance(task.donorLat, task.donorLng, student.lat, student.lng);
      const matchScore = (task.baseFare * task.surgeMultiplier) - (distKm * 0.4) + (student.rating * 0.5);
      return { student, distKm, matchScore };
    })
    .sort((a, b) => b.matchScore - a.matchScore)[0];
}`;

  const dbSchemaMongo = `// MongoDB / PostgreSQL Schemas
// 1. FoodItems Collection
{
  _id: ObjectId,
  donorId: String,
  foodName: String,
  type: Enum['Cooked Meal', 'Bakery', 'Packaged', 'Snacks', 'Beverage'],
  dietary: Enum['Veg', 'Non-Veg', 'Vegan', 'Halal'],
  portions: Number,
  prepTimestamp: Number,
  shelfLifeHours: Number,
  originalPrice: Number,
  currentPrice: Number,
  discountPercent: Number,
  safetyScore: Number,
  assignedStallId: String,
  status: Enum['available', 'reserved', 'in_transit', 'delivered_to_stall', 'sold_out']
}

// 2. SmartStalls Collection
{
  _id: ObjectId,
  name: String,
  code: String,
  type: Enum['Bus Terminal', 'Railway Station', 'University Gate', 'Public Hub'],
  chilledTemp: Number, // Target 2-5°C
  hotBoxTemp: Number, // Target >60°C
  sensorStatus: Enum['optimal', 'warning', 'critical'],
  vegCount: Number,
  nonVegCount: Number,
  freeTokensDispensedToday: Number
}`;

  const geminiSystemPromptText = `You are "EcoBite Bot", an intelligent AI assistant for ResQBite AI platform.
- Evaluate food visual freshness & packaging seal integrity using Gemini 3.6 Flash.
- Calculate dynamic clearance discounts and recommend physical Smart Stall allocation.
- Guide student gig-volunteers on shift routes and payout metrics.
- Provide multilingual voice & text support for needy citizens locating free food tokens.`;

  return (
    <div className="space-y-6 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-[#1f060b] to-[#0a0204] border border-rose-900/50 p-6 rounded-2xl shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 text-xs font-semibold border border-rose-800 mb-1">
            <Cpu className="w-3.5 h-3.5" />
            <span>Developer & Platform Deliverables</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">System Architecture & Technical Specifications</h1>
          <p className="text-xs text-rose-300/60 mt-0.5">
            Complete technical deliverables including high-level data flow, database schemas, core algorithmic logic, REST API specifications, and Gemini system prompts.
          </p>
        </div>
      </div>

      {/* 1. High-Level System Architecture Data Flow */}
      <div className="bg-[#0e0306] border border-[#2d0910] p-6 rounded-2xl shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Workflow className="w-5 h-5 text-rose-400" />
          1. High-Level Data Flow & Ecosystem Architecture
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
            <span className="font-bold text-rose-400 block text-sm">Step 1: Donors</span>
            <p className="text-rose-300/70">
              Restaurants & Bakeries log surplus batches. Gemini 3.6 Flash evaluates photo quality & packaging seal.
            </p>
          </div>

          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
            <span className="font-bold text-amber-400 block text-sm">Step 2: AI Engine</span>
            <p className="text-rose-300/70">
              Perishable decay formula applies 70%-85% discounts. Predictive engine routes food to optimal Smart Stall.
            </p>
          </div>

          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
            <span className="font-bold text-rose-300 block text-sm">Step 3: Student Logistics</span>
            <p className="text-rose-300/70">
              Gig volunteers claim auto-batched pickup tasks on phone, collect sanitized containers, and deliver to stalls.
            </p>
          </div>

          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] space-y-2">
            <span className="font-bold text-rose-200 block text-sm">Step 4: Smart Stalls</span>
            <p className="text-rose-300/70">
              Commuters & Students scan QR code for cheap meals. Subsidized Free Meal Tokens dispensed to needy citizens.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Core Algorithmic Code */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Terminal className="w-4 h-4 text-rose-400" />
              AI Dynamic Pricing & Shelf-Life Decay Algorithm
            </h3>
            <button
              onClick={() => copyToClipboard(dynamicPricingCode, 'pricing')}
              className="px-2.5 py-1 bg-[#050102] hover:bg-rose-950 text-xs text-rose-300 rounded-lg flex items-center gap-1 font-mono border border-[#2d0910]"
            >
              {copiedSection === 'pricing' ? <CheckCircle2 className="w-3.5 h-3.5 text-rose-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSection === 'pricing' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="bg-[#050102] p-4 rounded-xl text-[11px] font-mono text-rose-300 overflow-x-auto border border-[#2d0910]">
            {dynamicPricingCode}
          </pre>
        </div>

        <div className="bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Terminal className="w-4 h-4 text-rose-300" />
              Geospatial Student Route Matching Algorithm
            </h3>
            <button
              onClick={() => copyToClipboard(routeMatchingCode, 'route')}
              className="px-2.5 py-1 bg-[#050102] hover:bg-rose-950 text-xs text-rose-300 rounded-lg flex items-center gap-1 font-mono border border-[#2d0910]"
            >
              {copiedSection === 'route' ? <CheckCircle2 className="w-3.5 h-3.5 text-rose-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSection === 'route' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <pre className="bg-[#050102] p-4 rounded-xl text-[11px] font-mono text-rose-200 overflow-x-auto border border-[#2d0910]">
            {routeMatchingCode}
          </pre>
        </div>
      </div>

      {/* 3. Database Schemas */}
      <div className="bg-[#0e0306] border border-[#2d0910] p-6 rounded-2xl shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-400" />
            Database Schemas (MongoDB / PostgreSQL)
          </h3>
          <button
            onClick={() => copyToClipboard(dbSchemaMongo, 'db')}
            className="px-2.5 py-1 bg-[#050102] hover:bg-rose-950 text-xs text-rose-300 rounded-lg flex items-center gap-1 font-mono border border-[#2d0910]"
          >
            {copiedSection === 'db' ? <CheckCircle2 className="w-3.5 h-3.5 text-rose-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSection === 'db' ? 'Copied' : 'Copy Schema'}</span>
          </button>
        </div>
        <pre className="bg-[#050102] p-4 rounded-xl text-[11px] font-mono text-amber-300 overflow-x-auto border border-[#2d0910]">
          {dbSchemaMongo}
        </pre>
      </div>

      {/* 4. Gemini System Instructions */}
      <div className="bg-[#0e0306] border border-rose-900/50 p-6 rounded-2xl shadow-xl space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-rose-400" />
          Gemini 3.6 Flash System Instructions
        </h3>
        <pre className="bg-[#050102] p-4 rounded-xl text-[11px] font-mono text-rose-200 overflow-x-auto border border-[#2d0910]">
          {geminiSystemPromptText}
        </pre>
      </div>
    </div>
  );
};
