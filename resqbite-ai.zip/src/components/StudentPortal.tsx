import React, { useState } from 'react';
import { StudentVolunteer, LogisticsTask, ShiftSlot } from '../types';
import {
  Bike,
  Award,
  Wallet,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Flame,
  Star,
  MapPin,
  TrendingUp,
  Radio
} from 'lucide-react';

interface StudentPortalProps {
  students: StudentVolunteer[];
  tasks: LogisticsTask[];
  shifts: ShiftSlot[];
  onClaimTask: (taskId: string, studentId: string) => void;
  onUpdateTaskStatus: (taskId: string, status: 'picked_up' | 'delivered') => void;
  onClaimShift: (shiftId: string, studentId: string) => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({
  students,
  tasks,
  shifts,
  onClaimTask,
  onUpdateTaskStatus,
  onClaimShift,
}) => {
  const currentStudent = students[0] || {
    id: 'student-1',
    name: 'Aarav Sharma',
    university: 'State Institute of Technology',
    studentIdCard: 'SIT-2024-8841',
    transitMode: 'Scooter',
    activeShift: true,
    lat: 18.9650,
    lng: 72.8180,
    totalEarnings: 142.50,
    mealsRescuedCount: 128,
    carbonSavedKg: 184.2,
    badges: ['Zero-Waste Hero', '100 Delivery Streak', 'Late Night Guardian'],
    streakDays: 14,
    rating: 4.95,
  };

  const [sosActive, setSosActive] = useState(false);
  const [liveLocationSharing, setLiveLocationSharing] = useState(true);
  const [cashoutMessage, setCashoutMessage] = useState('');

  const handleCashout = () => {
    setCashoutMessage(`✓ ₹${currentStudent.totalEarnings.toFixed(2)} instantly transferred to connected UPI/Bank Account!`);
    setTimeout(() => setCashoutMessage(''), 4000);
  };

  return (
    <div className="space-y-6 text-slate-100">
      {/* Student Profile Header & Earnings Banner */}
      <div className="bg-[#0e0306] border border-rose-900/50 p-6 rounded-2xl shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#2d0910] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-800 to-rose-600 text-white font-black text-lg flex items-center justify-center shadow-lg">
              <Bike className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-white">{currentStudent.name}</h2>
                <span className="text-[10px] font-bold bg-rose-950 text-rose-300 px-2 py-0.5 rounded-full border border-rose-800 flex items-center gap-1">
                  <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                  {currentStudent.rating} ★
                </span>
              </div>
              <p className="text-xs text-rose-300/60">
                {currentStudent.university} • ID: <span className="font-mono">{currentStudent.studentIdCard}</span>
              </p>
            </div>
          </div>

          {/* Transit & Safety controls */}
          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={() => setLiveLocationSharing(!liveLocationSharing)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                liveLocationSharing
                  ? 'bg-rose-950 text-rose-200 border-rose-800'
                  : 'bg-[#050102] text-rose-400/50 border-[#2d0910]'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${liveLocationSharing ? 'text-rose-400 animate-pulse' : ''}`} />
              <span>{liveLocationSharing ? 'Live Location ON' : 'Location Paused'}</span>
            </button>

            <button
              onClick={() => setSosActive(!sosActive)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                sosActive
                  ? 'bg-red-600 text-white border-red-500 animate-bounce'
                  : 'bg-red-950/40 text-red-400 border-red-800/60 hover:bg-red-900/60'
              }`}
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{sosActive ? 'EMERGENCY SOS SENT!' : 'Safety SOS'}</span>
            </button>
          </div>
        </div>

        {/* SOS Alert Banner */}
        {sosActive && (
          <div className="bg-red-950/90 border border-red-500 p-3 rounded-xl text-xs text-red-200 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 animate-pulse" />
            <span>
              Emergency dispatch notified with your GPS coordinates. Student safety response agent en route.
            </span>
          </div>
        )}

        {/* Earnings Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910] flex items-center justify-between">
            <div>
              <span className="text-rose-300/60 block font-medium">Total Shift Earnings</span>
              <span className="text-2xl font-black text-rose-400">
                ₹{currentStudent.totalEarnings.toFixed(2)}
              </span>
            </div>
            <button
              onClick={handleCashout}
              className="px-3 py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xl text-xs shadow-md shadow-rose-950/50"
            >
              Instant Cashout
            </button>
          </div>

          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 block font-medium">Meals Rescued</span>
            <span className="text-2xl font-black text-white">{currentStudent.mealsRescuedCount} meals</span>
          </div>

          <div className="bg-[#050102] p-4 rounded-xl border border-[#2d0910]">
            <span className="text-rose-300/60 block font-medium">Carbon Offset</span>
            <span className="text-2xl font-black text-amber-400">{currentStudent.carbonSavedKg} kg CO₂e</span>
          </div>
        </div>

        {cashoutMessage && (
          <div className="p-3 bg-rose-950 border border-rose-800 text-rose-200 text-xs font-bold rounded-xl text-center">
            {cashoutMessage}
          </div>
        )}

        {/* Badges */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-xs text-rose-300/60 font-semibold flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-rose-400" /> Badges:
          </span>
          {currentStudent.badges.map((badge) => (
            <span
              key={badge}
              className="text-[11px] font-bold bg-[#050102] text-rose-200 px-2.5 py-1 rounded-full border border-[#2d0910] flex items-center gap-1"
            >
              <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
              {badge}
            </span>
          ))}
        </div>
      </div>

      {/* Main Grid: Shift Booking & Live Task Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Shift Booking Calendar */}
        <div className="lg:col-span-5 bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Clock className="w-4 h-4 text-rose-400" />
            2-Hour & 4-Hour Shift Booking
          </h3>
          <p className="text-xs text-rose-300/60">
            Claim evening slots around your class schedule. Guaranteed base stipend + per-task delivery payouts.
          </p>

          <div className="space-y-3">
            {shifts.map((shift) => (
              <div
                key={shift.id}
                className="bg-[#050102] p-3.5 rounded-xl border border-[#2d0910] flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-white block">{shift.timeWindow} ({shift.date})</span>
                  <span className="text-rose-300/60 text-[11px] flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3 h-3 text-rose-400" /> {shift.stallName}
                  </span>
                </div>

                <div className="text-right">
                  <span className="font-bold text-rose-400 text-sm block">
                    +₹{shift.stipendAmount.toFixed(2)} Stipend
                  </span>
                  {shift.status === 'open' ? (
                    <button
                      onClick={() => onClaimShift(shift.id, currentStudent.id)}
                      className="mt-1 px-3 py-1 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-lg text-[11px] shadow-sm shadow-rose-950"
                    >
                      Claim Shift
                    </button>
                  ) : (
                    <span className="text-[10px] font-bold text-rose-400/50 bg-[#0e0306] px-2 py-0.5 rounded border border-[#2d0910]">
                      Claimed
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Live Task Feed */}
        <div className="lg:col-span-7 bg-[#0e0306] border border-[#2d0910] p-5 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-rose-400" />
              Live Gig Pickup Tasks Nearby
            </h3>
            <span className="text-xs font-mono text-rose-300 bg-rose-950 px-2 py-0.5 rounded border border-rose-800">
              {tasks.filter((t) => t.status !== 'delivered').length} Active
            </span>
          </div>

          <div className="space-y-4">
            {tasks.map((task) => (
              <div
                key={task.id}
                className="bg-[#050102] border border-[#2d0910] rounded-xl p-4 space-y-3 text-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-white text-sm">{task.foodName}</h4>
                    <p className="text-rose-300/60 text-[11px]">
                      From: <strong className="text-rose-200">{task.donorName}</strong> ({task.donorAddress})
                    </p>
                    <p className="text-rose-300/60 text-[11px]">
                      To: <strong className="text-rose-400">{task.stallName}</strong>
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-base font-extrabold text-rose-400 block">
                      +₹{task.totalPayout.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-rose-400/50 font-mono">
                      Distance: {task.distanceKm} km
                    </span>
                  </div>
                </div>

                {/* Status action bar */}
                <div className="flex items-center justify-between pt-2 border-t border-[#2d0910]">
                  <span className="text-rose-300/60 font-medium">
                    Status:{' '}
                    <strong className="text-amber-400 uppercase font-mono">{task.status}</strong>
                  </span>

                  {task.status === 'available' && (
                    <button
                      onClick={() => onClaimTask(task.id, currentStudent.id)}
                      className="px-4 py-1.5 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-lg text-xs transition-all shadow-md shadow-rose-950/50"
                    >
                      Accept Task
                    </button>
                  )}

                  {task.status === 'assigned' && (
                    <button
                      onClick={() => onUpdateTaskStatus(task.id, 'picked_up')}
                      className="px-4 py-1.5 bg-rose-800 hover:bg-rose-700 text-white font-bold rounded-lg text-xs transition-all shadow-md"
                    >
                      Mark Picked Up
                    </button>
                  )}

                  {task.status === 'picked_up' && (
                    <button
                      onClick={() => onUpdateTaskStatus(task.id, 'delivered')}
                      className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition-all"
                    >
                      Complete Delivery to Stall
                    </button>
                  )}

                  {task.status === 'delivered' && (
                    <span className="text-rose-400 font-bold flex items-center gap-1 text-xs">
                      <CheckCircle2 className="w-4 h-4 text-rose-400" /> Delivered & Paid
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
