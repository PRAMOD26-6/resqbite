import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_STALLS,
  INITIAL_FOOD_ITEMS,
  INITIAL_STUDENTS,
  INITIAL_LOGISTICS_TASKS,
  INITIAL_SHIFTS,
  INITIAL_TRANSACTIONS,
  INITIAL_IMPACT,
} from './src/data/initialData';
import { FoodItem, LogisticsTask, TransactionOrder } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory data store for live state
let stalls = [...INITIAL_STALLS];
let foodItems = [...INITIAL_FOOD_ITEMS];
let students = [...INITIAL_STUDENTS];
let tasks = [...INITIAL_LOGISTICS_TASKS];
let shifts = [...INITIAL_SHIFTS];
let transactions = [...INITIAL_TRANSACTIONS];
let impact = { ...INITIAL_IMPACT };

// Server-side Gemini AI setup
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.error('Failed to initialize GoogleGenAI client:', err);
  }
}

// Dynamic pricing algorithm helper
function calculateDynamicPricing(
  originalPrice: number,
  prepTimestamp: number,
  shelfLifeHours: number,
  demandMultiplier: number = 1.0
) {
  const hoursElapsed = Math.max(0, (Date.now() - prepTimestamp) / (1000 * 3600));
  const remainingHours = Math.max(0, shelfLifeHours - hoursElapsed);
  const decayRatio = Math.min(1.0, hoursElapsed / shelfLifeHours);

  // Base discount starts at 70% and scales up to 85% as time ticks
  let discountPercent = Math.round(70 + decayRatio * 15 * demandMultiplier);
  discountPercent = Math.min(88, Math.max(70, discountPercent));

  let currentPrice = +(originalPrice * (1 - discountPercent / 100)).toFixed(2);
  const isFreeTokenEligible = remainingHours <= 1.5 || discountPercent >= 85;

  return { currentPrice, discountPercent, isFreeTokenEligible, remainingHours };
}

// 1. GET ALL PLATFORM DATA
app.get('/api/data', (_req, res) => {
  // Refresh dynamic prices on read
  foodItems = foodItems.map((item) => {
    const pricing = calculateDynamicPricing(
      item.originalPrice,
      item.prepTimestamp,
      item.shelfLifeHours
    );
    return {
      ...item,
      currentPrice: pricing.currentPrice,
      discountPercent: pricing.discountPercent,
      isFreeTokenEligible: pricing.isFreeTokenEligible,
    };
  });

  res.json({
    stalls,
    foodItems,
    students,
    tasks,
    shifts,
    transactions,
    impact,
  });
});

// 2. AI FOOD INSPECTOR & QUALITY GUARD (Gemini 3.6 Flash)
app.post('/api/food-items/inspect', async (req, res) => {
  const { foodName, foodType, dietary, photoBase64, description } = req.body;

  let safetyScore = 95;
  let safetyNotes = 'Visual inspection completed: Food containers sealed and verified hygienic.';
  let packagingVerified = true;
  let suggestedDiscount = 75;
  let recommendedStallId = stalls[0]?.id || 'stall-1';

  if (ai) {
    try {
      const parts: any[] = [
        {
          text: `You are the ResQBite AI Food Safety Guard. Analyze this surplus food entry:
Name: ${foodName || 'Surplus Dish'}
Category: ${foodType} (${dietary})
Description: ${description || 'Freshly prepared surplus meal from partner kitchen.'}

Evaluate the safety, freshness indicator score (0-100), packaging integrity, and recommend optimal distribution node.
Output ONLY JSON in this format:
{
  "safetyScore": 95,
  "safetyNotes": "High hygiene confidence. Verified packaging seal and temperature control.",
  "packagingVerified": true,
  "suggestedDiscount": 75,
  "recommendedStallName": "Central Railway Station Stall B",
  "recommendedStallId": "stall-1"
}`
        }
      ];

      if (photoBase64) {
        const mimeType = photoBase64.startsWith('data:image/png') ? 'image/png' : 'image/jpeg';
        const cleanBase64 = photoBase64.replace(/^data:image\/\w+;base64,/, '');
        parts.unshift({
          inlineData: {
            mimeType,
            data: cleanBase64,
          }
        });
      }

      const aiRes = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: { parts },
        config: {
          responseMimeType: 'application/json',
        }
      });

      if (aiRes.text) {
        const parsed = JSON.parse(aiRes.text);
        if (typeof parsed.safetyScore === 'number') safetyScore = parsed.safetyScore;
        if (parsed.safetyNotes) safetyNotes = parsed.safetyNotes;
        if (typeof parsed.packagingVerified === 'boolean') packagingVerified = parsed.packagingVerified;
        if (typeof parsed.suggestedDiscount === 'number') suggestedDiscount = parsed.suggestedDiscount;
        if (parsed.recommendedStallId) recommendedStallId = parsed.recommendedStallId;
      }
    } catch (err) {
      console.error('Gemini Food Inspection fallback:', err);
    }
  }

  res.json({
    safetyScore,
    safetyNotes,
    packagingVerified,
    suggestedDiscount,
    recommendedStallId,
  });
});

// 3. LOG NEW SURPLUS FOOD ITEM
app.post('/api/food-items', (req, res) => {
  const {
    donorName,
    foodName,
    type,
    dietary,
    portions,
    shelfLifeHours,
    originalPrice,
    photoUrl,
    assignedStallId,
  } = req.body;

  const targetStall = stalls.find((s) => s.id === assignedStallId) || stalls[0];
  const prepTimestamp = Date.now();
  const pricing = calculateDynamicPricing(originalPrice || 180.0, prepTimestamp, shelfLifeHours || 6);

  const newItem: FoodItem = {
    id: `food-${Date.now()}`,
    donorId: 'donor-partner',
    donorName: donorName || 'Partner Kitchen',
    donorLocation: { name: 'City Center Hub', lat: 18.965, lng: 72.82 },
    foodName,
    type: type || 'Cooked Meal',
    dietary: dietary || 'Veg',
    portions: portions || 20,
    remainingPortions: portions || 20,
    prepTime: 'Just Now',
    prepTimestamp,
    shelfLifeHours: shelfLifeHours || 6,
    originalPrice: originalPrice || 180.0,
    currentPrice: pricing.currentPrice,
    discountPercent: pricing.discountPercent,
    isFreeTokenEligible: pricing.isFreeTokenEligible,
    assignedStallId: targetStall.id,
    assignedStallName: targetStall.name,
    status: 'available',
    safetyScore: 96,
    safetyNotes: 'AI Guard Passed: Core prep temp and eco-packaging verified.',
    packagingVerified: true,
    photoUrl: photoUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80',
    ttiTemperature: 65,
  };

  foodItems.unshift(newItem);

  // Auto-generate student logistics task
  const newTask: LogisticsTask = {
    id: `task-${Date.now()}`,
    foodItemId: newItem.id,
    foodName: `${newItem.foodName} (${newItem.portions} portions)`,
    portions: newItem.portions,
    donorName: newItem.donorName,
    donorAddress: 'Donor Kitchen Hub',
    donorLat: newItem.donorLocation.lat,
    donorLng: newItem.donorLocation.lng,
    stallId: targetStall.id,
    stallName: targetStall.name,
    stallLat: targetStall.lat,
    stallLng: targetStall.lng,
    status: 'available',
    distanceKm: 1.8,
    baseFare: 50.00,
    surgeMultiplier: 1.15,
    totalPayout: +(50.00 * 1.15).toFixed(2),
    estimatedMinutes: 14,
    createdAt: new Date().toISOString(),
  };

  tasks.unshift(newTask);
  impact.mealsRescued += newItem.portions;

  res.json({ success: true, item: newItem, task: newTask });
});

// 4. STUDENT CLAIM TASK & UPDATE LOGISTICS STATUS
app.post('/api/tasks/claim', (req, res) => {
  const { taskId, studentId } = req.body;
  const taskIndex = tasks.findIndex((t) => t.id === taskId);
  if (taskIndex === -1) return res.status(404).json({ error: 'Task not found' });

  const student = students.find((s) => s.id === studentId) || students[0];
  tasks[taskIndex].status = 'assigned';
  tasks[taskIndex].studentId = student.id;
  tasks[taskIndex].studentName = student.name;

  // Update corresponding food item status
  const foodItem = foodItems.find((f) => f.id === tasks[taskIndex].foodItemId);
  if (foodItem) foodItem.status = 'reserved';

  res.json({ success: true, task: tasks[taskIndex] });
});

app.post('/api/tasks/update-status', (req, res) => {
  const { taskId, status } = req.body; // 'picked_up' or 'delivered'
  const taskIndex = tasks.findIndex((t) => t.id === taskId);
  if (taskIndex === -1) return res.status(404).json({ error: 'Task not found' });

  tasks[taskIndex].status = status;
  const task = tasks[taskIndex];

  const foodItem = foodItems.find((f) => f.id === task.foodItemId);
  if (foodItem) {
    if (status === 'picked_up') foodItem.status = 'in_transit';
    if (status === 'delivered') {
      foodItem.status = 'delivered_to_stall';

      // Increment stall stock counts
      const stall = stalls.find((s) => s.id === task.stallId);
      if (stall) {
        if (foodItem.dietary === 'Veg') stall.vegCount += foodItem.remainingPortions;
        else stall.nonVegCount += foodItem.remainingPortions;
      }

      // Disburse payout to student
      if (task.studentId) {
        const student = students.find((s) => s.id === task.studentId);
        if (student) {
          student.totalEarnings += task.totalPayout;
          student.mealsRescuedCount += task.portions;
          student.carbonSavedKg += +(task.portions * 1.4).toFixed(1);
        }
      }

      impact.studentIncomeDisbursed += task.totalPayout;
      impact.co2eOffsetKg += +(task.portions * 1.5).toFixed(1);
      impact.methaneOffsetKg += +(task.portions * 0.2).toFixed(1);
    }
  }

  res.json({ success: true, task });
});

// 5. SMART STALL BUYER CHECKOUT & FREE TOKEN DISPENSER
app.post('/api/stalls/checkout', (req, res) => {
  const { stallId, foodItemId, qty, isFreeToken, buyerName } = req.body;
  const food = foodItems.find((f) => f.id === foodItemId);
  const stall = stalls.find((s) => s.id === stallId);

  if (!food || !stall) return res.status(400).json({ error: 'Item or stall not found' });

  const quantity = qty || 1;
  const unitPrice = isFreeToken ? 0 : food.currentPrice;
  const totalAmount = +(unitPrice * quantity).toFixed(2);

  food.remainingPortions = Math.max(0, food.remainingPortions - quantity);
  if (food.remainingPortions === 0) food.status = 'sold_out';

  if (isFreeToken) stall.freeTokensDispensedToday += quantity;

  // Deduct stall category count
  if (food.dietary === 'Veg') stall.vegCount = Math.max(0, stall.vegCount - quantity);
  else stall.nonVegCount = Math.max(0, stall.nonVegCount - quantity);

  const newTx: TransactionOrder = {
    id: `tx-${Date.now()}`,
    buyerName: buyerName || (isFreeToken ? 'Free Meal Beneficiary' : 'Commuter Buyer'),
    buyerType: isFreeToken ? 'Free Token Beneficiary' : 'Student',
    items: [{ foodName: food.foodName, qty: quantity, unitPrice }],
    totalAmount,
    stallName: stall.name,
    pickupTokenQR: `RESQ-QR-${Math.floor(1000 + Math.random() * 9000)}`,
    status: 'claimed',
    timestamp: 'Just Now',
  };

  transactions.unshift(newTx);
  if (!isFreeToken) impact.consumerMoneySaved += +((food.originalPrice - food.currentPrice) * quantity).toFixed(2);

  res.json({ success: true, transaction: newTx, remainingPortions: food.remainingPortions });
});

// 6. STUDENT SHIFT CLAIMING
app.post('/api/shifts/claim', (req, res) => {
  const { shiftId, studentId } = req.body;
  const shift = shifts.find((s) => s.id === shiftId);
  if (!shift) return res.status(404).json({ error: 'Shift not found' });

  shift.status = 'claimed';
  shift.claimedByStudentId = studentId || 'student-1';
  res.json({ success: true, shift });
});

// 7. ECOBITE BOT AI ASSISTANT (Gemini 3.6 Flash)
app.post('/api/chat', async (req, res) => {
  const { message, persona } = req.body;

  let botReply = 'Welcome to ResQBite AI! I am here to help you rescue surplus meals, navigate stall routes, or manage deliveries.';

  if (ai) {
    try {
      const activeFoodSummary = foodItems
        .filter((f) => f.remainingPortions > 0)
        .map((f) => `${f.foodName} (${f.dietary}) at ${f.assignedStallName} for ₹${f.currentPrice} (${f.discountPercent}% off, ${f.remainingPortions} left)`)
        .join('; ');

      const stallSummary = stalls
        .map((s) => `${s.name}: ${s.vegCount} Veg, ${s.nonVegCount} Non-Veg, Temp ${s.chilledTemp}°C / ${s.hotBoxTemp}°C`)
        .join('; ');

      const systemPrompt = `You are "EcoBite Bot", an intelligent AI assistant for the ResQBite AI surplus food platform.
Current User Persona: ${persona || 'general'}
Active Food Listings: ${activeFoodSummary || 'Multiple fresh discounted meals available.'}
Physical Smart Stalls: ${stallSummary}

Your Goal:
- For Consumers: Recommend closest cheap meals (₹20-₹80) or free tokens based on dietary preferences and location.
- For Restaurants/Donors: Explain how to log surplus food, how AI price decay works, and how ESG tax credits are calculated.
- For Student Volunteers: Provide shift guidance, route optimization advice, and earnings breakdown.
- For Needy/Charity: Help locate nearby Smart Stalls dispensing Free Meal Tokens.

Keep your response friendly, energetic, concise (2-4 sentences max), clear, and actionable. Use Indian Rupees (₹) for all pricing and amounts.`;

      const aiRes = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: message,
        config: {
          systemInstruction: systemPrompt,
        },
      });

      if (aiRes.text) {
        botReply = aiRes.text.trim();
      }
    } catch (err) {
      console.error('Gemini Chat error:', err);
    }
  } else {
    // Helpful rule-based responses if API key isn't provided
    const lower = (message || '').toLowerCase();
    if (lower.includes('veg') || lower.includes('cheap') || lower.includes('meal')) {
      botReply = `Found 18 Veg portions of Paneer Butter Masala at Central Railway Station Stall B for just ₹45.00 (75% OFF!). You can scan to claim right now.`;
    } else if (lower.includes('student') || lower.includes('shift') || lower.includes('earnings')) {
      botReply = `There is an open 2-hour evening shift at Metro Bus Terminal Smart Hub offering a ₹300 stipend + ₹75 task payout.`;
    } else if (lower.includes('donor') || lower.includes('tax') || lower.includes('log')) {
      botReply = `Logging surplus food automatically generates an automated ESG Compliance Certificate & 100% Tax Credit Receipt for your restaurant!`;
    }
  }

  res.json({ reply: botReply });
});

// 8. GET SYSTEM TECHNICAL SPECIFICATIONS & DIAGRAM DATA
app.get('/api/system-docs', (_req, res) => {
  res.json({
    architecture: {
      name: 'ResQBite AI Ecosystem',
      dataFlow: [
        'Donors (Restaurants/Bakeries) -> AI Food Safety Guard (Visual Gemini 3.6 Flash) -> Dynamic Price & Decay Engine',
        'Surplus Batches -> Predictive Stall Allocation Engine -> Student Gig Routing & Payout Engine',
        'Student Logistics Agents (Gig Volunteers) -> Physical Smart Stalls (IoT Insulated Storage Nodes)',
        'Consumers & Beneficiaries -> Express QR Checkout / Subsidized Free Meal Token Dispenser'
      ],
      pricingFormula: `CurrentPrice = OriginalPrice * (1 - DiscountPercent / 100)
DiscountPercent = Clamp(70 + (HoursElapsed / ShelfLifeHours) * 15 * DemandMultiplier, 70%, 88%)
FreeTokenCondition = RemainingShelfLifeHours <= 1.5 || DiscountPercent >= 85%`,
      geospatialRoutingFormula: `MatchScore = BaseFare * SurgeMultiplier - (DistanceKm * 0.4) + StudentRatingMultiplier`
    },
    databaseSchema: {
      FoodItems: '{ id, donorId, foodName, type, dietary, portions, prepTimestamp, shelfLifeHours, originalPrice, currentPrice, discountPercent, safetyScore, assignedStallId, status }',
      SmartStalls: '{ id, name, code, type, locationName, lat, lng, chilledTemp, hotBoxTemp, vegCount, nonVegCount, freeTokensDispensedToday }',
      LogisticsTasks: '{ id, foodItemId, donorName, stallId, studentId, status, distanceKm, baseFare, surgeMultiplier, totalPayout }',
      StudentVolunteers: '{ id, name, university, transitMode, totalEarnings, mealsRescuedCount, carbonSavedKg, rating }',
      Transactions: '{ id, buyerName, buyerType, totalAmount, stallName, pickupTokenQR, timestamp }'
    }
  });
});

// Vite & Static file serving handling
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ResQBite AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
